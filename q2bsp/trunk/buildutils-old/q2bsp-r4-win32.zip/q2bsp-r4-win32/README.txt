=========================
 BUILDUTILS Q2BSP README
=========================

These are the Quake II compilation tools:

 - q2bsp: compiles a .map file into a .bsp file

 - q2vis: generates visibility tree

 - q2rad: calculates map lighting

 - q2bspinfo: shows various statistics about a .bsp file

Please visit http://peter-b.co.uk/software/ for the latest
release.

The Trac site at https://adidas.servegame.org/projects/buildutils/ has
the Subversion repository, wiki and bug tracker. Any and all bug
reports are gratefully received.

Features
--------

 - Greatly improved portability

 - New short command-line options

 - Improved HINT support to assist terrain generator tools.

 - Support for QuArK's Enhanced Texture Positioning MAP files. Maps
   created with QuArK have highly accurate texture positioning and
   orientation.

History
-------

This distribution is based on Geoffrey DeWan's enhanced version of the
Quake II build tools. He had this to say:

  This archive contains the source to my version of the quake2 compile
  tools.  I am pretty much releasing the source under the same terms
  as the id released the original source.  I have included the text
  files that originally came with with the original id release of the
  compile tools, which resides in the id_docs/ directory.  gdd_files/
  contains the documentation and executables I released with each of
  the last releases of qbsp3, rvis3, and qrad3.  utils3/ contains the
  source itself.  While it can be copied over the original source, it
  is self-contained.  The last versions of these utilies were compiled
  with either Microsoft Visual C versions 5 and 6.

  It is not my intention for providing support on how to this this
  working, but I may help if I have the time.

This was in 2001.  At the time of writing, I have been totally unable
to locate the original source code for the Quake II build tools, and
have in particular been unable to locate the license.  I've therefore
decided that the GNU General Public License is a suitable license to
release these under (see COPYING).

Should anyone know anything about this, please let me know.

Building on Windows
-------------------

To build on Windows, you will need Cygwin (http://cygwin.com). Use the
`setup.exe' program distributed by Cygwin to install gcc and make
(along with all the core tools).  You should then be able to follow
the instructions given in INSTALL.

Note that you'll probably want to do:

  ./configure CC='gcc -mno-cygwin'

in order to avoid having to drag cygwin1.dll around (most of a
megabyte).
