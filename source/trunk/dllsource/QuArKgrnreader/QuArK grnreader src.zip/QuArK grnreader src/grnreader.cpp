#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
//#include <sstream>
//#include <string>

#include "AutoGranny.h"
//#include "GR2Format.h"

#include "Granny.h"
#pragma warning(disable:4996) // deprecated functions

typedef float	granny_real32;

#define M_PI	3.14159265358979323846

//GrannyStack stack;

int Indentation = 0;

void Indent(FILE* f)
	{
		for (int i = 0; i < Indentation; i++)
			{
				fprintf(f, " ");
			}
	}

void __cdecl log(int a, int b, char* msg)
	{
		printf("-- Log (%d %d) %s\n", a, b, msg);
	}

GrannyLogger logger = { &log, &log };

//These defines allow you to control what data you want to output:
#define OutputArtToolData
#define OutputExporterData
#define OutputModelData
#define OutputMeshData
#define OutputSkeletonData
#define OutputBoneData
//#define OutputBoneDataBB

// Causes grnreader to crash with some .gr2 models when next 2 lines are not commented out.
// If just one line is put back in, no crash, but no materials section either.
//#define OutputMaterialBindingData
//#define OutputMaterialData

//#define OutputTextureData
//#define OutputPixelData
#define OutputAnimationData
#define OutputTrackGroupData
//#define OutputDetailTrackGroupData

int TicksPerFrame = 1; // GetTicksPerFrame()
float FramesPerSecond = 60.0;

float TimeToFrame(float time)
	{
		return time * FramesPerSecond * TicksPerFrame;
	}
float FrameToTime(float time)
	{
		return float(time) / (FramesPerSecond * TicksPerFrame);
	}

void OutputExtendedData(FILE* f, t_ExtendedData ExtendedData)
	{
		return; //FIXME: NOT WORKING!
		for (int i = 0; i < ExtendedData.Properties_count; i++)
			{
				Indent(f);
				fprintf(f, "extended data(\n");
				Indentation += 2;
				Indent(f);
				fprintf(f, "extended data name: %s\n", ExtendedData.Properties[i].Name);
				Indent(f);
				fprintf(f, "extended data type: %d\n", ExtendedData.Properties[i].Type);
				//FIXME: MISSING STUFF HERE!
				Indent(f);
				fprintf(f, "extended data len: %d\n", ExtendedData.Properties[i].Len);
				Indent(f);
				fprintf(f, "extended data unk2: %d\n", ExtendedData.Properties[i].Unk2);
				Indent(f);
				fprintf(f, "extended data unk3: %d\n", ExtendedData.Properties[i].Unk3);
				Indent(f);
				fprintf(f, "extended data unk4: %d\n", ExtendedData.Properties[i].Unk4);
				Indent(f);
				fprintf(f, "extended data unk5: %d\n", ExtendedData.Properties[i].Unk5);
				Indentation -= 2;
				Indent(f);
				fprintf(f, ")\n");
			}
	}

#ifdef OutputMaterialData
	void OutputMaterial(FILE* f, t_Materials* Material); //Prototype
#endif

#ifdef OutputMaterialBindingData
	void OutputMaterialBinding(FILE* f, t_MaterialBindings MaterialBindings)
		{
			Indent(f);
			fprintf(f, "material binding (\n");
			Indentation += 2;
			#ifdef OutputMaterialData
				OutputMaterial(f, MaterialBindings.Material);
			#endif
			Indentation -= 2;
			Indent(f);
			fprintf(f, ")\n");
		}
#endif

#ifdef OutputMeshData
	void OutputMesh(FILE* f, t_Meshes* mesh, int nverts = -1, int nindices = -1)
		{
			if (nverts == -1)
				nverts = (*GrannyGetMeshVertexCount)(mesh);
			if (nindices == -1)
				nindices = (*GrannyGetMeshIndexCount)(mesh);

			fprintf(f, "MESHNAME: %s\n  group bones = %d\n", mesh->Name, mesh->BoneBindings_count);

			for (int i = 0; i < mesh->BoneBindings_count; ++i)
				{
					fprintf(f, "%d BindingBoneName: %s\n", i, mesh->BoneBindings[i].BoneName);
				}

			fprintf(f, "set Group Vertices\ntotal Tri-Groups verts: %d\n(\n", nverts);

			t_Vertex_PWNT3432* verts = new t_Vertex_PWNT3432[nverts];
			(*GrannyCopyMeshVertices)(mesh, GrannyPWNT3432VertexType, verts);

			for (int i = 0; i < nverts; ++i)
				{
					fprintf(f, "setVert temp %d [%f,%f,%f]\n", i,
						verts[i].Position[0], verts[i].Position[1], verts[i].Position[2]);
					fprintf(f, "setTVert temp %d [%f,%f,%f]\n", i,
						verts[i].TextureCoordinates0[0], verts[i].TextureCoordinates0[1], 0.0f);
					fprintf(f, "setNormal temp %d [%f,%f,%f]\n", i,
						verts[i].Normal[0], verts[i].Normal[1], verts[i].Normal[2]);
					fprintf(f, "setBoneIndices temp %d [%d,%d,%d,%d]\n", i,
						verts[i].BoneIndices[0], verts[i].BoneIndices[1], verts[i].BoneIndices[2], verts[i].BoneIndices[3]);
					fprintf(f, "setBoneWeights temp %d [%d,%d,%d,%d]\n", i,
						verts[i].BoneWeights[0], verts[i].BoneWeights[1], verts[i].BoneWeights[2], verts[i].BoneWeights[3]);
				}
			delete[] verts;

			fprintf(f, ")\n\n");

			if (mesh->PrimaryTopology != NULL)
				{
					for (int e = 0; e < mesh->PrimaryTopology->Groups_count; e++)
						{
							t_Indices16* indices = new t_Indices16[nindices];

							(*GrannyCopyMeshIndices)(mesh, 2, indices); //FIXME: Hardcoded 2!

							int initIND = mesh->PrimaryTopology->Groups[e].TriFirst;
							int finishIND = (mesh->PrimaryTopology->Groups[e].TriCount)-1;

							int indexIND = mesh->PrimaryTopology->Groups[e].MaterialIndex;

							#ifdef _DEBUG
								printf("init: %d, finish. %d, index: %d\n",  initIND, finishIND, indexIND);
							#endif
							fprintf(f, "CreateMeshes = (\nmesh numfaces:%d\n", (initIND + finishIND)+1);

							//for (int i = 0; i < nindices/3; ++i)
							for (int i = initIND; i <  (initIND + finishIND)+1; ++i)
								{
									fprintf(f, "setFace temp %d [%d,%d,%d]\n", i,
										indices[i*3+0].Int16,
										indices[i*3+1].Int16,
										indices[i*3+2].Int16);

									//printf("indices %d\n",  nindices*3);

									#ifdef _DEBUG
										printf("indices %d\n",  i);
									#endif
									//fprintf(f, "setFaceMatID temp %d %d\n", i+1, indexIND);
									//IndexCount = i;
								}


							delete[] indices;

							fprintf(f, ")\n\n");
						}
				}

			#ifdef OutputMaterialBindingData
				for (int i = 0; i < mesh->MaterialBindings_count; i++)
					{
						OutputMaterialBinding(f, mesh->MaterialBindings[i]);
					}
			#endif

			// Prints to .ms output file the bone name, frame min and max bounding box coords, ex:
			// bonebinding (
			//   name: Bip_Masha L Hand
			//   OBBMin: [-8.174599,-5.880524,-23.018808]
			//   OBBMax: [39.566097,8.321136,15.006678]
			// )
			#ifdef OutputBoneDataBB
				for (int i = 0; i < mesh->BoneBindings_count; ++i)
					{
						fprintf(f, "bonebinding (\n");
						fprintf(f, "  name: %s\n", mesh->BoneBindings[i].BoneName);
						fprintf(f, "  OBBMin: [%f,%f,%f]\n", mesh->BoneBindings[i].OBBMin[0], mesh->BoneBindings[i].OBBMin[1], mesh->BoneBindings[i].OBBMin[2]);
						fprintf(f, "  OBBMax: [%f,%f,%f]\n", mesh->BoneBindings[i].OBBMax[0], mesh->BoneBindings[i].OBBMax[1], mesh->BoneBindings[i].OBBMax[2]);
						for (int j = 0; j < mesh->BoneBindings[i].TriangleIndices_count; ++j)
							{
								fprintf(f, "vertex: %d\n", mesh->BoneBindings[i].TriangleIndices[j]);
							}
						fprintf(f, ")\n");
					}
			#endif

		}
#endif

#ifdef OutputTextureData
	void OutputMap(FILE* f, t_Maps Map)
		{
			Indent(f);
			fprintf(f, "map (\n");
			Indentation += 2;
			Indent(f);
			fprintf(f, "map name: %s\n", Map.Usage);
			#ifdef OutputMaterialData
				OutputMaterial(f, Map.Map);
			#endif
			Indentation -= 2;
			Indent(f);
			fprintf(f, ")\n");
		}
#endif

#ifdef OutputPixelData
	void OutputMIPLevel(FILE* f, t_MIPLevels MIPLevel)
		{
			Indent(f);
			fprintf(f, "miplevel (\n");
			Indentation += 2;
			Indent(f);
			fprintf(f, "stride: %d\n", MIPLevel.Stride);
			Indent(f);
			fprintf(f, "pixel_count: %d\n", MIPLevel.Pixels_count);
			Indent(f);
			fprintf(f, "pixel: ");
			t_Pixels* Current_Pixel = MIPLevel.Pixels;
			for (int i = 0; i < MIPLevel.Pixels_count; i++)
				{
					if (i != 0)
						fprintf(f, ",");
					fprintf(f, "%d", Current_Pixel->UInt8);
					Current_Pixel += sizeof(t_Pixels);
				}
			fprintf(f, "\n");
			Indentation -= 2;
			Indent(f);
			fprintf(f, ")\n");
		}
#endif

#ifdef OutputPixelData
	void OutputImage(FILE* f, t_Images Image)
		{
			for (int i = 0; i < Image.MIPLevels_count; i++)
				{
					OutputMIPLevel(f, Image.MIPLevels[i]);
				}
		}
#endif

#ifdef OutputTextureData
	void OutputTexture(FILE* f, t_Texture* Texture)
		{
			//FIXME: Start using GrannyConvertPixelFormat to convert to uncompressed BMP?
			if (Texture == NULL)
				return;
			Indent(f);
			fprintf(f, "texture (\n");
			Indentation += 2;
			Indent(f);
			fprintf(f, "fromfilename: %s\n", Texture->FromFileName);
			Indent(f);
			fprintf(f, "texturetype: %d\n", Texture->TextureType);
			Indent(f);
			fprintf(f, "width: %d\n", Texture->Width);
			Indent(f);
			fprintf(f, "height: %d\n", Texture->Height);
			Indent(f);
			fprintf(f, "encoding: %d\n", Texture->Encoding);
			Indent(f);
			fprintf(f, "subformat: %d\n", Texture->SubFormat);
			Indent(f);
			fprintf(f, "BytesPerPixel: %d\n", Texture->Layout.BytesPerPixel);
			Indent(f);
			fprintf(f, "ShiftForComponent: [%d,%d,%d,%d]\n", Texture->Layout.ShiftForComponent[0], Texture->Layout.ShiftForComponent[1], Texture->Layout.ShiftForComponent[2], Texture->Layout.ShiftForComponent[3]);
			Indent(f);
			fprintf(f, "BitsForComponent: [%d,%d,%d,%d]\n", Texture->Layout.BitsForComponent[0], Texture->Layout.BitsForComponent[1], Texture->Layout.BitsForComponent[2], Texture->Layout.BitsForComponent[3]);
			#ifdef OutputPixelData
				for (int i = 0; i < Texture->Images_count; i++)
					{
						OutputImage(f, Texture->Images[i]);
					}
			#endif
			OutputExtendedData(f, Texture->ExtendedData);
			Indentation -= 2;
			Indent(f);
			fprintf(f, ")\n");
		}
#endif

#ifdef OutputMaterialData
	void OutputMaterial(FILE* f, t_Materials* Material)
		{
			Indent(f);
			fprintf(f, "material (\n");
			Indentation += 2;
			Indent(f);
			fprintf(f, "material name: %s\n", Material->Name);
			#ifdef OutputTextureData
				for (int i = 0; i < Material->Maps_count; i++)
					{
						OutputMap(f, Material->Maps[i]);
					}
				OutputTexture(f, Material->Texture);
			#endif
			OutputExtendedData(f, Material->ExtendedData);
			Indentation -= 2;
			Indent(f);
			fprintf(f, ")\n");
		}
#endif

#ifdef OutputBoneData
	void OutputBone(FILE* f, t_Bones Bone)
	{
		Indent(f);
		fprintf(f, "bone (\n");
		Indentation += 2;
		Indent(f);
		fprintf(f, "bone name: %s\n", Bone.Name);
		Indent(f);
		fprintf(f, "bone parentindex: %d\n", Bone.ParentIndex);
		Indent(f);
 	    fprintf(f, "bone transform dimensions: %d\n", Bone.Transform.Dimensions);
		Indent(f);
		fprintf(f, "bone transform origin: [%f,%f,%f]\n",
			Bone.Transform.Origin.Point[0],
			Bone.Transform.Origin.Point[1],
			Bone.Transform.Origin.Point[2]);
		Indent(f);
		fprintf(f, "bone transform rotation: [%f,%f,%f,%f]\n",
			Bone.Transform.Rotation.Point[0],
			Bone.Transform.Rotation.Point[1],
			Bone.Transform.Rotation.Point[2],
			Bone.Transform.Rotation.Point[3]);
		Indent(f);
		fprintf(f, "bone transform scale: [%f,%f,%f,%f,%f,%f,%f,%f,%f]\n",
			Bone.Transform.Scale[0],
			Bone.Transform.Scale[1],
			Bone.Transform.Scale[2],
			Bone.Transform.Scale[3],
			Bone.Transform.Scale[4],
			Bone.Transform.Scale[5],
			Bone.Transform.Scale[6],
			Bone.Transform.Scale[7],
			Bone.Transform.Scale[8]);
		Indent(f);
		fprintf(f, "bone InverseWorldTransform: [%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f]\n",
			Bone.InverseWorldTransform[0],
			Bone.InverseWorldTransform[1],
			Bone.InverseWorldTransform[2],
			Bone.InverseWorldTransform[3],
			Bone.InverseWorldTransform[4],
			Bone.InverseWorldTransform[5],
			Bone.InverseWorldTransform[6],
			Bone.InverseWorldTransform[7],
			Bone.InverseWorldTransform[8],
			Bone.InverseWorldTransform[9],
			Bone.InverseWorldTransform[10],
			Bone.InverseWorldTransform[11],
			Bone.InverseWorldTransform[12],
			Bone.InverseWorldTransform[13],
			Bone.InverseWorldTransform[14],
			Bone.InverseWorldTransform[15]);
		Indent(f);
		fprintf(f, "bone LODError: %f\n", Bone.LODError);
		OutputExtendedData(f, Bone.ExtendedData);
		Indentation -= 2;
		Indent(f);
		fprintf(f, ")\n");
	}
#endif

#ifdef OutputSkeletonData
	void OutputSkeleton(FILE* f, t_Skeletons* Skeleton)
	{
		if (Skeleton == NULL)
			return;
		Indent(f);
		fprintf(f, "skeleton (\n");
		Indentation += 2;
		Indent(f);
		fprintf(f, "skeleton name: %s\n", Skeleton->Name);
		Indent(f);
		fprintf(f, "skeleton LOD type: %d\n", Skeleton->LODType);
		#ifdef OutputBoneData
			for (int i = 0; i < Skeleton->Bones_count; i++)
				{
					OutputBone(f, Skeleton->Bones[i]);
				}
		#endif
		OutputExtendedData(f, Skeleton->ExtendedData);
		Indentation -= 2;
		Indent(f);
		fprintf(f, ")\n");
	}
#endif

#ifdef OutputTrackGroupData
	// Handles the computation of all the trackgroup bones one animation frame at a time.
	void OutputTrackGroup(FILE* f, t_TrackGroups* TrackGroup, float frameCounter, float time, float* timeKeys)
		{
			Indent(f);
			fprintf(f, "boneindex [orientation qx,qy,qz] [position x,y,z]\n");
			for (int ianim=0, nanim=(int)frameCounter; ianim<nanim; ++ianim)
				{
					Indent(f);
					fprintf(f, "KeyFrame: %d\n", ianim);
	//				Indent(f);
	//				fprintf(f, "KeyTime: %f\n", timeKeys[ianim]);

					//FIXME: Output animation frame data!
					// When done testing put entire for loop below inside this for loop to get all frames.
                    Indent(f);
                    fprintf(f, "(\n");
                    Indentation += 2;
                    for (int i = 0; i < TrackGroup->TransformTracks_count; i++)
                        {
                            Indent(f);
                            fprintf(f, "boneindex %d ", i);
//                            Indent(f);
//                            fprintf(f, "boneindex %d\n", i);
        //                    Indent(f);
        //                    fprintf(f, "(\n");
//                            Indentation += 2;
        //                    Indent(f);
        //                    fprintf(f, "Flags %d\n", TrackGroup->TransformTracks[i].Flags);
        //                    Indent(f);
        //                    fprintf(f, "OrientationCurve\n");
        //                    Indent(f);
        //                    fprintf(f, "(\n");
        //                    Indentation += 2;
                      //      Indent(f);
                      //      fprintf(f, "OrientationCurve Format %d\n", ((t_CurveDataHeader*)TrackGroup->TransformTracks[i].OrientationCurve)->Format);
        //                    Indent(f);
        //                    fprintf(f, "Degree %d\n", ((t_CurveDataHeader*)TrackGroup->TransformTracks[i].OrientationCurve)->Degree);
                            switch (((t_CurveDataHeader*)TrackGroup->TransformTracks[i].OrientationCurve)->Format)
                                {
                                //FIXME: Add missing stuff!
                                case 1:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "Padding %d\n", ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Padding);
        //                                Indent(f);
        //                                fprintf(f, "Knots:  %d\n", ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Knots_count);
        //                                Indent(f);
        //                                fprintf(f, "Controls:  %d\n", ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls_count);
        //                                    Indent(f);
        //                                    fprintf(f, "(\n");
//                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Knots_count; j++)
                                                {
                                                    float Knot = ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Knots[j].Real32;
                                                    if (Knot >= timeKeys[ianim])
                                                        {
    //                                                        Indent(f);
    //                                                        fprintf(f, "Knot %d: %f\n", j, Knot);
        //                                                    Indent(f);
        //                                                    fprintf(f, "Control %d: qx, qy, qz, qw\n", j);
//                                                            Indent(f);
//                                                            fprintf(f, "Orientation %d: [%f %f %f %f]\n",
//                                                                j,
                                                         //   fprintf(f, "[%f %f %f %f] ",
                                                            fprintf(f, "%f %f %f ",
                                                                ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[(j*4)+0].Real32,
                                                                ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[(j*4)+1].Real32,
                                                            //    ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[(j*4)+2].Real32,
                                                            //    ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[(j*4)+3].Real32);
                                                                ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[(j*4)+2].Real32);
                                                            break;
                                                        }
                                                }
//                                            Indentation -= 2;
        //                                    Indent(f);
        //                                    fprintf(f, ")\n");
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Knots_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "Knot %d: %f\n", j, ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Knots[j].Real32);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "Control %d: %f\n", j, ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[j].Real32);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                case 2:
                                    {
                                        fprintf(f, "0.0 0.0 0.0 ");
        //                                Indent(f);
                                        fprintf(f, "Format 2 OrientationCurve Dimension %d\n", ((t_CurveData_Daldentity*)TrackGroup->TransformTracks[i].OrientationCurve)->Dimension);
                                    }
                                    break;
                                case 4:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "Padding %d\n", ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Padding);
//                                        Indent(f);
//                                        fprintf(f, "Orientation [%f %f %f]\n",
                                        fprintf(f, "%f %f %f ",
                                            ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[0],
                                            ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[1],
                                            ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[2]);
                                        break;
                                    }
                                case 5:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "Padding %d\n", ((t_CurveData_D4Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Padding);
//                                        Indent(f);
//                                        fprintf(f, "Orientation [%f %f %f %f]\n", 
                                     //   fprintf(f, "[%f %f %f %f] ", 
                                        fprintf(f, "%f %f %f ", 
                                            ((t_CurveData_D4Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[0],
                                            ((t_CurveData_D4Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[1],
                                        //    ((t_CurveData_D4Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[2],
                                        //    ((t_CurveData_D4Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[3]);
                                            ((t_CurveData_D4Constant32f*)TrackGroup->TransformTracks[i].OrientationCurve)->Controls[2]);
                                        break;
                                    }
                                case 8:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "ScaleOffsetTableEntries %d\n", ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->ScaleOffsetTableEntries);
        //                                Indent(f);
        //                                fprintf(f, "OneOverKnotScale %f\n", ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->OneOverKnotScale);
        //                                Indent(f);
        //                                fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count/4);
        //                                Indent(f);
        //                                fprintf(f, "(\n");
        //                                Indentation += 2;
										int foundknot = 0;
                                        for (int j = 0,n=((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count/4; j<n; ++j)
                                            {
                                                float Knot = float(((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt16) / ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->OneOverKnotScale;
                                                if (Knot >= timeKeys[ianim])
                                                    {
                                                    //    Indent(f);
                                                    //    fprintf(f, "n %d + (j %d x 3)\n", n, j);
                                                    //    Indent(f);
                                                    //    fprintf(f, "KnotsControl-0 %d / %f * %f * %f * %f\n", ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt16, 65535.0f, 2.0f, float(M_PI), 2.0f);
                                                    //    Indent(f);
													//	fprintf(f, "j %d: Knot: %f timeKeys[ianim]: %f\n", j, Knot, timeKeys[ianim]);
        //                                                Indent(f);
        //                                                fprintf(f, "KnotsControl %d: qx, qy, qz\n", j);
//                                                        Indent(f);
//                                                        fprintf(f, "Orientation %d: [%f %f %f]\n",
//                                                            j,
                                                        fprintf(f, "%f %f %f ",
                                                      //      ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3+0)].UInt16 / 65535.0f*2.0f*float(M_PI)*2.0f,
                                                      //      ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3+1)].UInt16 / 65535.0f*2.0f*float(M_PI)*2.0f,
                                                      //      ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3+2)].UInt16 / 65535.0f*2.0f*float(M_PI)*2.0f);
                                                            ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3+0)].UInt16 / 65535.0f,
                                                            ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3+1)].UInt16 / 65535.0f,
                                                            ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3+2)].UInt16 / 65535.0f);
														foundknot = 1;
                                                        break;
                                                    }
                                            }
									/*	if (foundknot == 0)
											{
												int n = ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count/4;
												fprintf(f, "%f %f %f ",
											//		((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[((n-1)*3)].UInt16 / 65535.0f*2.0f*float(M_PI)*2.0f,
											//		((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[((n-1)*3+1)].UInt16 / 65535.0f*2.0f*float(M_PI)*2.0f,
											//		((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[((n-1)*3+2)].UInt16 / 65535.0f*2.0f*float(M_PI)*2.0f);
													((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[((n-1)*3)].UInt16 / 65535.0f,
													((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[((n-1)*3+1)].UInt16 / 65535.0f,
													((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[((n-1)*3+2)].UInt16 / 65535.0f);
											}*/
        //                                Indentation -= 2;
        //                                Indent(f);
        //                                fprintf(f, ")\n");
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "KnotsControl %d: %d\n", j, ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt16);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                case 9:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "ScaleOffsetTableEntries %d\n", ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->ScaleOffsetTableEntries);
        //                                Indent(f);
        //                                fprintf(f, "OneOverKnotScale %f\n", ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->OneOverKnotScale);
        //                                Indent(f);
        //                                fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count/4);
        //                                    Indent(f);
        //                                    fprintf(f, "(\n");
        //                                    Indentation += 2;
											int KnotsControls = ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count;
                                            for (int j=0, n=KnotsControls/4; j<n; ++j)
                                                {
                                            //    fprintf(f, "KnotTime %d time %f\n", j, float(((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt8) / ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->OneOverKnotScale);
                                            //    fprintf(f, "KnotsControl %d %d\n", n+(j*3), ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n+(j*3)].UInt8);
                                            //    fprintf(f, "KnotsControl %d %d\n", n+(j*3)+1, ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n+(j*3)+1].UInt8);
                                            //    fprintf(f, "KnotsControl %d %d\n", n+(j*3)+2, ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n+(j*3)+2].UInt8);
                                                
                                                    float Knot = float(((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt8) / ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->OneOverKnotScale;
                                                    if (Knot >= timeKeys[ianim])
                                                        {
	//														Indent(f);
	//														fprintf(f, "Knot %d: %f\n", j, Knot);
		//													Indent(f);
		//													fprintf(f, "KnotsControl %d: t, qx, qy, qz\n", j);
														//	Indent(f);
														//	fprintf(f, "Orientation %d: [%d %d %d %d]\n",
														//		j,
														//		((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt8,
														//		((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3)+0].UInt8,
														//		((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3)+1].UInt8,
														//		((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3)+2].UInt8);
//															Indent(f);
//															fprintf(f, "Orientation %d: [%f %f %f]\n",
//																j,
															fprintf(f, "%f %f %f ",
																float(((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3)+0].UInt8) / 255.0,
																float(((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3)+1].UInt8) / 255.0,
																float(((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[n + (j*3)+2].UInt8) / 255.0);
                                                            break;
                                                        }
												}
        //                                    Indentation -= 2;
        //                                    Indent(f);
        //                                    fprintf(f, ")\n");
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "KnotsControl %d: %d\n", j, ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt8);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                case 10:
                                    {
                                        Indent(f);
                                        fprintf(f, "Format 10 OrientationCurve\n");
                                        Indent(f);
                                        fprintf(f, "OneOverKnotScaleTrunc %d\n", ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->OneOverKnotScaleTrunc);
                                        Indent(f);
                                        fprintf(f, "ControlScales [%f,%f,%f]\n",
                                            ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->ControlScales[0],
                                            ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->ControlScales[1],
                                            ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->ControlScales[2]);
                                        Indent(f);
                                        fprintf(f, "ControlOffsets [%f,%f,%f]\n",
                                            ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->ControlOffsets[0],
                                            ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->ControlOffsets[1],
                                            ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->ControlOffsets[2]);
                                        Indent(f);
                                        fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count);
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "KnotsControl %d: %d\n", j, ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls[j].UInt16);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                }
        //                    Indentation -= 2;
        //                    Indent(f);
        //                    fprintf(f, ")\n");

        //                    Indent(f);
        //                    fprintf(f, "PositionCurve\n");
        //                    Indent(f);
        //                    fprintf(f, "(\n");
        //                    Indentation += 2;
   //                         Indent(f);
   //                         fprintf(f, "PositionCurve Format %d\n", ((t_CurveDataHeader*)TrackGroup->TransformTracks[i].PositionCurve)->Format);
        //                    Indent(f);
        //                    fprintf(f, "Degree %d\n", ((t_CurveDataHeader*)TrackGroup->TransformTracks[i].PositionCurve)->Degree);
                            switch (((t_CurveDataHeader*)TrackGroup->TransformTracks[i].PositionCurve)->Format)
                                {
                                //FIXME: Add missing stuff!
                                case 1:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "Padding %d\n", ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Padding);
        //                                Indent(f);
        //                                fprintf(f, "Knots: %d\n", ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Knots_count);
        //                                Indent(f);
        //                                fprintf(f, "Controls: %d\n", ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls_count);
                                            
        //                                    Indent(f);
        //                                    fprintf(f, "(\n");
//                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Knots_count; j++)
                                                {
                                                    float Knot = ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Knots[j].Real32;
                                                    if (Knot >= timeKeys[ianim])
                                                        {
	//														Indent(f);
	//														fprintf(f, "Knot %d: %f\n", j, Knot);
		//													Indent(f);
		//													fprintf(f, "Control %d: x, y, z\n", j);
//															Indent(f);
//															fprintf(f, "PositionCurve %d: [%f %f %f]\n",
//																j,
															fprintf(f, "%f %f %f\n",
																((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls[(j*3)+0].Real32,
																((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls[(j*3)+1].Real32,
																((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls[(j*3)+2].Real32);
                                                            break;
                                                        }
                                                }
//                                            Indentation -= 2;
        //                                    Indent(f);
        //                                    fprintf(f, ")\n");
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Knots_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "Knot %d: %f\n", j, ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Knots[j].Real32);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "Control %d: %f\n", j, ((t_CurveData_DaK32fC32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls[j].Real32);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                case 2:
                                    {
                                        fprintf(f, "0.0 0.0 0.0\n");
        //                                Indent(f);
                                        fprintf(f, "Format 2 PositionCurve Dimension %d\n", ((t_CurveData_Daldentity*)TrackGroup->TransformTracks[i].PositionCurve)->Dimension);
                                    }
                                    break;
                                case 4:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "Padding %d\n", ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].PositionCurve)->Padding);
//                                        Indent(f);
//                                        fprintf(f, "PositionCurve [%f %f %f]\n",
                                        fprintf(f, "%f %f %f\n",
                                            ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls[0],
                                            ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls[1],
                                            ((t_CurveData_D3Constant32f*)TrackGroup->TransformTracks[i].PositionCurve)->Controls[2]);
                                        break;
                                    }
                                case 8:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "ScaleOffsetTableEntries %d\n", ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->ScaleOffsetTableEntries);
        //                                Indent(f);
        //                                fprintf(f, "OneOverKnotScale %f\n", ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScale);
        //                                Indent(f);
        //                                fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/3);
        //                                    Indent(f);
        //                                    fprintf(f, "(\n");
//                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/3; j++)
                                                {
													float Knot = float(((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt16) / ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScale;
													if (Knot >= timeKeys[ianim])
														{
	//														Indent(f);
	//														fprintf(f, "Knot %d: %f\n", j, Knot);
		//													Indent(f);
		//													fprintf(f, "KnotsControl %d: x, y, z\n", j);
//															Indent(f);
//															fprintf(f, "PositionCurve %d: [%f %f %f]\n",
//															j,
															fprintf(f, "%f %f %f\n",
																(((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[(j*3+0)].UInt16)-16379.0f / 65535.0f*float(M_PI)*2.0f,
																(((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[(j*3+1)].UInt16)/65535.0f*float(M_PI)*2.0f,
																(((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[(j*3+2)].UInt16)/65535.0f*float(M_PI)*2.0f);
                                                            break;
                                                        }
                                                }
//                                            Indentation -= 2;
        //                                    Indent(f);
        //                                    fprintf(f, ")\n");
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].OrientationCurve)->KnotsControls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "KnotsControl %d: %d\n", j, ((t_CurveData_D4nK16uC15u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt16);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                case 9:
                                    {
                                        Indent(f);
										fprintf(f, "Format 9 PositionCurve\n");
                                        Indent(f);
                                        fprintf(f, "ScaleOffsetTableEntries %d\n", ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].PositionCurve)->ScaleOffsetTableEntries);
                                        Indent(f);
                                        fprintf(f, "OneOverKnotScale %f\n", ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScale);
                                        Indent(f);
                                        fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count);
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "KnotsControl %d: %d\n", j, ((t_CurveData_D4nK8uC7u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt8);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                case 10:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "OneOverKnotScaleTrunc %d\n", ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScaleTrunc);
        //                                Indent(f);
        //                                fprintf(f, "ControlScales [%f,%f,%f]\n",
        //                                    ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0],
        //                                    ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1],
        //                                    ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2]);
        //                                Indent(f);
        //                                fprintf(f, "ControlOffsets [%f,%f,%f]\n",
        //                                    ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
        //                                    ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
        //                                    ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
                                    /*    int DummyNumber = ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count;
                                        if ((DummyNumber % 3) == 0)
                                            {
        //                                        Indent(f);
        //                                        fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/3);
        //                                        Indent(f);
        //                                        fprintf(f, "(\n");
//                                                Indentation += 2;
                                                for (int j = 0; j < ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/3; j++)
                                                    {
														float Knot = float(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt16) / (((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScaleTrunc / 4);
														if (Knot >= timeKeys[ianim])
															{
	//															Indent(f);
																fprintf(f, "Knot %d: %f\n", j, Knot);
		//														Indent(f);
		//														fprintf(f, "KnotsControl %d: x, y, z\n", j);
//																Indent(f);
//																fprintf(f, "PositionCurve %d: [%f %f %f]\n",
//																	j,
																fprintf(f, "[%f %f %f]\n",
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[(j*3+0)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[(j*3+1)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[(j*3+2)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
																break;
															}
														if (j = ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/3)
															{
																fprintf(f, "[%f %f %f]\n",
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((j-1)*3+0)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((j-1)*3+1)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((j-1)*3+2)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
																fprintf(f, "NO PositionCurve Format 10 DummyNumber 3 ");
																fprintf(f, "j %d, n %d, Knot %f, ianim %d, timeKeys[ianim] %f\n", j, ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/3, Knot, ianim, timeKeys[ianim]);
																fprintf(f, "FIXED [%f %f %f]\n",
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((j-1)*3+0)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((j-1)*3+1)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((j-1)*3+2)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
																break;
															}
                                                    }
//                                                Indentation -= 2;
        //                                        Indent(f);
        //                                        fprintf(f, ")\n");
                                            }
                                        else
                                            {*/
        //                                        Indent(f);
        //                                        fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/4);
        //                                        Indent(f);
        //                                        fprintf(f, "(\n");
//                                                Indentation += 2;
												int foundknot = 0;
                                                for (int j = 0,n=((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/4; j<n; ++j)
                                                    {
														float Knot = float(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt16) / float(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScaleTrunc);

														if (Knot >= timeKeys[ianim])
															{
		//														Indent(f);
		//														fprintf(f, "KnotsControl %d: x, y, z\n", j);
//																Indent(f);
//																fprintf(f, "PositionCurve %d: [%f %f %f]\n",
//																	j,
																fprintf(f, "%f %f %f\n",
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + (j*3+0)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + (j*3+1)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
																	(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + (j*3+2)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);

																foundknot = 1;
																fprintf(f, "Knot %d: %f time %f\n", j, Knot, timeKeys[ianim]);
																break;
															}
                                                    }
												if (foundknot == 0)
													{
														int n = ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/4;
														fprintf(f, "%f %f %f\n",
															(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((n-1)*3+0)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
															(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((n-1)*3+1)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
															(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((n-1)*3+2)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
														fprintf(f, "PositionCurve Format 10 KNOT less knots: %d %d %d\n", (((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+0)].UInt16), (((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+1)].UInt16), (((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+2)].UInt16));
														fprintf(f, "n %d, ianim %d, timeKeys[ianim] %f\n", n, ianim, timeKeys[ianim]);
														fprintf(f, "FIXED [%f %f %f]\n",
															(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+0)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
															(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+1)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
															(((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+2)].UInt16) * ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
													}
//                                                Indentation -= 2;
        //                                        Indent(f);
        //                                        fprintf(f, ")\n");
                                    //        }
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "KnotsControl %d: %d\n", j, ((t_CurveData_D3K16uC16u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt16);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                case 11:
                                    {
        //                                Indent(f);
        //                                fprintf(f, "OneOverKnotScaleTrunc %d\n", ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScaleTrunc);
        //                                Indent(f);
        //                                fprintf(f, "ControlScales [%f,%f,%f]\n",
        //                                    ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0],
        //                                    ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1],
        //                                    ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2]);
        //                                Indent(f);
        //                                fprintf(f, "ControlOffsets [%f,%f,%f]\n", ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0], ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1], ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
        //                                Indent(f);
        //                                fprintf(f, "KnotsControls: %d\n", ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/4);
        //                                    Indent(f);
        //                                    fprintf(f, "(\n");
//                                            Indentation += 2;
											int foundknot = 0;
                                            for (int j = 0,n=((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/4; j<n; ++j)
                                                {
                                                    float Knot = float(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt8) * 65536.0f / 256.0f / ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->OneOverKnotScaleTrunc;
                                                    if (Knot >= timeKeys[ianim])
                                                        {
	//														Indent(f);
	//														fprintf(f, "Knot %d: %f\n", j, Knot);
		//													Indent(f);
		//													fprintf(f, "KnotsControl %d: x, y, z\n", j);
//															Indent(f);
//															fprintf(f, "PositionCurve %d: [%f %f %f]\n",
//																j,
															fprintf(f, "%f %f %f\n",
																(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + (j*3+0)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
																(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + (j*3+1)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
																(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + (j*3+2)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);

															foundknot = 1;
														//	fprintf(f, "Knot %d: %f time %f\n", j, Knot, timeKeys[ianim]);
                                                            break;
                                                        }
                                                }
												if (foundknot == 0)
													{
														int n = ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count/4;
														fprintf(f, "%f %f %f\n",
															(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((n-1)*3+0)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
															(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((n-1)*3+1)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
															(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[((n-1)*3+2)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
														fprintf(f, "PositionCurve Format 11 KNOT less knots: %d %d %d\n", (((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+0)].UInt8), (((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+1)].UInt8), (((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+2)].UInt8));
														fprintf(f, "n %d, ianim %d, timeKeys[ianim] %f\n", n, ianim, timeKeys[ianim]);
														fprintf(f, "FIXED [%f %f %f]\n",
															(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+0)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[0] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[0],
															(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+1)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[1] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[1],
															(((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[n + ((n-1)*3+2)].UInt8) * ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlScales[2] + ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->ControlOffsets[2]);
													}
//                                            Indentation -= 2;
        //                                    Indent(f);
        //                                    fprintf(f, ")\n");
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "KnotsControl %d: %d\n", j, ((t_CurveData_D3K8uC8u*)TrackGroup->TransformTracks[i].PositionCurve)->KnotsControls[j].UInt8);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                }
        //                    Indentation -= 2;
        //                    Indent(f);
        //                    fprintf(f, ")\n");

/*                            Indent(f);
                            fprintf(f, "ScaleShearCurve\n");
                            Indent(f);
                            fprintf(f, "(\n");
                            Indentation += 2;
                            Indent(f);
                            fprintf(f, "Format %d\n", ((t_CurveDataHeader*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Format);
                            Indent(f);
                            fprintf(f, "Degree %d\n", ((t_CurveDataHeader*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Degree);
                            switch (((t_CurveDataHeader*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Format)
                                {
                                case 2:
                                    {
                                        Indent(f);
                                        fprintf(f, "Dimension %d\n", ((t_CurveData_Daldentity*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Dimension);
                                    }
                                    break;
                                case 3:
                                    {
                                        Indent(f);
                                        fprintf(f, "Padding %d\n", ((t_CurveData_DaConstant32f*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Padding);
                                        Indent(f);
                                        fprintf(f, "Controls: %d\n", ((t_CurveData_DaConstant32f*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Controls_count);
                                        #ifdef OutputDetailTrackGroupData
                                            Indent(f);
                                            fprintf(f, "(\n");
                                            Indentation += 2;
                                            for (int j = 0; j < ((t_CurveData_DaConstant32f*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Controls_count; j++)
                                                {
                                                    Indent(f);
                                                    fprintf(f, "Control %d: %f\n", j, ((t_CurveData_DaConstant32f*)TrackGroup->TransformTracks[i].ScaleShearCurve)->Controls[j].Real32);
                                                }
                                            Indentation -= 2;
                                            Indent(f);
                                            fprintf(f, ")\n");
                                        #endif
                                        break;
                                    }
                                }

                            Indentation -= 2;
                            Indent(f);
                            fprintf(f, ")\n");
*/
//                            Indentation -= 2;
        //                    Indent(f);
        //                    fprintf(f, ")\n");
                        }
                    Indentation -= 2;
                    Indent(f);
                    fprintf(f, ")\n");
				}

			//FIXME: MISSING STUFF HERE!
			OutputExtendedData(f, TrackGroup->ExtendedData);
		}
#endif

#ifdef OutputAnimationData
	// Main function call for importing a .gr2 animation file.
	void OutputAnimation(FILE* f, t_Animations* Animation)
		{
			Indent(f);
			fprintf(f, "animation (\n");
			Indentation += 2;
			Indent(f);
			fprintf(f, "animation name %s\n", Animation->Name);
			Indent(f);
			fprintf(f, "animation duration: %f\n", Animation->Duration);
			Indent(f);
			fprintf(f, "animation timestep: %f\n", Animation->TimeStep);
			Indent(f);
			fprintf(f, "animation oversampling: %f\n", Animation->Oversampling);

			#ifdef OutputTrackGroupData
				// Animation frames are computed by interpolation based on
				// the total number of frames (the frameCounter)
				// and that amount (the frameCounter) is computed below.
				// Using the code below makes the frameCounter = 903 frames!?
				//	float duration = Animation->Duration;
				//	const float FREQ = 1.0f / 60.0f; // sample it at 60h, same as Animation->TimeStep below.
				// t = animation timestep: 0.016667
				//	fprintf(f, "duration: %f\n", duration);
				//	fprintf(f, "FREQ: %f\n", FREQ);
				//		int frameCounter = 0;
				//		for (float t=0; t<duration; t+=FREQ)
				//		{
				//			frameCounter++; 
				//		}
				//		int frameCounter = (int)Animation->Duration;

				//float timestep = Animation->TimeStep; //WAY TOO MANY
				float timestep = 1.0f / 15.0f;

				float time = FrameToTime(0);

				// Build Default Time
				float frameCounter = Animation->Duration / timestep;

				float* timeKeys = new float[(int)frameCounter];
				Indent(f);
				fprintf(f, "AnimationFrames: %d\n", (int)frameCounter);

				float curtime = time;
				for (int timekey=0; timekey<(int)frameCounter; ++timekey, curtime += timestep)
					{
						timeKeys[timekey] = curtime;
					//	fprintf(f, "timekey %d , curtime %f\n", timekey, curtime);
					}



				for (int i = 0; i < Animation->TrackGroups_count; i++)
					{
						Indent(f);
						fprintf(f, "trackgroup name %s\n", Animation->TrackGroups[i]->Name);
						Indent(f);
						fprintf(f, "trackgroup bones %d\n", Animation->TrackGroups[i]->TransformTracks_count);
						Indent(f);
						fprintf(f, "(\n");
						Indentation += 2;

						t_TrackGroups* TrackGroup = Animation->TrackGroups[i];
						// Outputs a list of all the bones used for this TrackGroup, animation.
						for (int j = 0; j < TrackGroup->TransformTracks_count; j++)
							{
								Indent(f);
								fprintf(f, "%d, %s\n", j, TrackGroup->TransformTracks[j].Name);
							}

						Indentation -= 2;
						Indent(f);
						fprintf(f, ")\n\n");

						Indent(f);
						fprintf(f, "(\n");
						Indentation += 2;

						OutputTrackGroup(f, TrackGroup, frameCounter, time, timeKeys);

						Indentation -= 2;
						Indent(f);
						fprintf(f, ")\n");
					}
				delete[] timeKeys;
			#endif
			Indentation -= 2;
			Indent(f);
			fprintf(f, ")\n");
		}
#endif


// Main function call for importing a .gr2 static base model file.
void OutputModel(FILE* f, t_FileInfo* modelinfo, t_Models* Model)
	{
		Indent(f);
		fprintf(f, "model (\n");
		Indentation += 2;
		Indent(f);
		fprintf(f, "model name %s\n", Model->Name);
		Indent(f);
		fprintf(f, "model initial placement dimensions: %d\n", Model->InitialPlacement.Dimensions);
		Indent(f);
		fprintf(f, "model initial placement origin: [%f,%f,%f]\n",
			Model->InitialPlacement.Origin.Point[0],
			Model->InitialPlacement.Origin.Point[1],
			Model->InitialPlacement.Origin.Point[2]);
		Indent(f);
		fprintf(f, "model initial placement rotation: [%f,%f,%f,%f]\n",
			Model->InitialPlacement.Rotation.Point[0],
			Model->InitialPlacement.Rotation.Point[1],
			Model->InitialPlacement.Rotation.Point[2],
			Model->InitialPlacement.Rotation.Point[3]);
		Indent(f);
		fprintf(f, "model initial placement scale: [%f,%f,%f,%f,%f,%f,%f,%f,%f]\n",
			Model->InitialPlacement.Scale[0],
			Model->InitialPlacement.Scale[1],
			Model->InitialPlacement.Scale[2],
			Model->InitialPlacement.Scale[3],
			Model->InitialPlacement.Scale[4],
			Model->InitialPlacement.Scale[5],
			Model->InitialPlacement.Scale[6],
			Model->InitialPlacement.Scale[7],
			Model->InitialPlacement.Scale[8]);
		//FIXME: MISSING STUFF HERE!
		/*granny_int32 MeshBindings_count;
		t_MeshBindings * MeshBindings;*/

		#ifdef OutputSkeletonData
			OutputSkeleton(f, Model->Skeleton);
		#endif
		Indentation -= 2;
		Indent(f);
		fprintf(f, ")\n\n");
	}


int main(int argc, char** argv)
	{
		printf("grnreader.exe (Modified for QuArK) - version 1.0\n\n");
		if (argc != 2)
			{
				printf("Please run as something like '%s HC_cathedral.gr2'.\n", argv[0]);
				exit(-1);
			}

		LoadStuff();

		printf("Version granny2.dll: %s\n", ((*GrannyGetVersionString)()));

		(*GrannySetLogCallback)(&logger);

		char* file = argv[1];
		//(*GrannyConvertFileToRaw)(file, "C:\\test.txt");
		GrannyFile* modelfile = (*GrannyReadEntireFile)(file);
		if (! modelfile)
			{
				printf("Couldn't read GR2 file '%s' - maybe it's not the right name, or not in the right folder, or an invalid GR2 file.\n", file);
				UnloadStuff();
				exit(-2);
			}
		t_FileInfo* modelinfo = (*GrannyGetFileInfo)(modelfile);
		if (! modelinfo)
			{
				printf("Couldn't get GR2 FileInfo. I have no idea why.\n");
				UnloadStuff();
				exit(-3);
			}

		//FIXME: Call if needed: GrannyTransformFile

		//Opening also cleans output file
		FILE* f = fopen("output.tmp", "w");

		#ifdef OutputArtToolData
			if (modelinfo->ArtToolInfo)
				{
					printf("Outputting art tool info...\n");
					Indent(f);
					fprintf(f, "art tool (\n");
					Indentation += 2;
					Indent(f);
					fprintf(f, "art tool name: %s\n", modelinfo->ArtToolInfo->FromArtToolName);
					Indent(f);
					fprintf(f, "art tool revision: [%d, %d]\n", modelinfo->ArtToolInfo->ArtToolMajorRevision, modelinfo->ArtToolInfo->ArtToolMinorRevision);
					Indent(f);
					fprintf(f, "art tool units per meter: %f\n", modelinfo->ArtToolInfo->UnitsPerMeter);
					Indent(f);
					fprintf(f, "art tool origin: [%f,%f,%f]\n",
						modelinfo->ArtToolInfo->Origin[0],
						modelinfo->ArtToolInfo->Origin[1],
						modelinfo->ArtToolInfo->Origin[2]);
					Indent(f);
					fprintf(f, "art tool right vector: [%f,%f,%f]\n",
						modelinfo->ArtToolInfo->RightVector[0],
						modelinfo->ArtToolInfo->RightVector[1],
						modelinfo->ArtToolInfo->RightVector[2]);
					Indent(f);
					fprintf(f, "art tool up vector: [%f,%f,%f]\n",
						modelinfo->ArtToolInfo->UpVector[0],
						modelinfo->ArtToolInfo->UpVector[1],
						modelinfo->ArtToolInfo->UpVector[2]);
					Indent(f);
					fprintf(f, "art tool back vector: [%f,%f,%f]\n",
						modelinfo->ArtToolInfo->BackVector[0],
						modelinfo->ArtToolInfo->BackVector[1],
						modelinfo->ArtToolInfo->BackVector[2]);
					Indentation -= 2;
					Indent(f);
					fprintf(f, ")\n\n");
				}
		#endif
		#ifdef OutputExporterData
			if (modelinfo->ExporterInfo)
				{
					printf("Outputting exporter info...\n");
					Indent(f);
					fprintf(f, "exporter tool (\n");
					Indentation += 2;
					Indent(f);
					fprintf(f, "exporter name: %s\n", modelinfo->ExporterInfo->ExporterName);
					Indent(f);
					fprintf(f, "exporter revision: [%d, %d]\n", modelinfo->ExporterInfo->ExporterMajorRevision, modelinfo->ExporterInfo->ExporterMinorRevision);
					Indent(f);
					fprintf(f, "exporter customization: %d\n", modelinfo->ExporterInfo->ExporterCustomization);
					Indent(f);
					fprintf(f, "exporter build number: %d\n", modelinfo->ExporterInfo->ExporterBuildNumber);
					Indentation -= 2;
					Indent(f);
					fprintf(f, ")\n\n");
				}
		#endif

		#ifdef OutputModelData
			printf("Outputting models...\n");
		   // Lines below outputs multiple sets of bones.
			for (int i = 0; i < modelinfo->Models_count; i++)
				{
					OutputModel(f, modelinfo, modelinfo->Models[i]);
				}
			// Line below outputs only 1st set of bones but causes crash on animation output.
		//	OutputModel(f, modelinfo, modelinfo->Models[0]);
		#endif

		#ifdef OutputMeshData
			printf("Outputting meshes...\n");
			for (int i = 0; i < modelinfo->Meshes_count; i++)
				{
					OutputMesh(f, modelinfo->Meshes[i]);
				}
		#endif

		#ifdef OutputAnimationData
			printf("Outputting animations...\n");
			for (int i = 0; i < modelinfo->Animations_count; i++)
				{
					OutputAnimation(f, modelinfo->Animations[i]);
				}
		#endif
		
		fclose(f);

		if (rename("output.tmp", "output.ms"))
			{
				printf("Unable to rename output. Filename: output.tmp.\n");
			}
		else
			{
				printf("Created output.ms.\n");
			}

		UnloadStuff();

		return 0;	
	}
