#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
//#include <sstream>
//#include <string>

#include "AutoGranny.h"
//#include "GR2Format.h"

#include "Granny.h"
typedef DWORD (WINAPI *PFNGRANNYCONVERTFILETORAWPROC) (const char* src, const char *dst); 
#pragma warning(disable:4996) // deprecated functions

GrannyStack stack;

void __cdecl log(int a, int b, char* msg)
{
	printf("-- Log (%d %d) %s\n", a, b, msg);
}
GrannyLogger logger = { &log, &log };

void dumpStruct(void* data, int n);

#define OutputBoneData
#define OutputTextureData
//#define OutputPixelData
#define OutputTrackGroupData


void OutputMesh(FILE* f, t_Meshes* mesh, int nverts = -1, int nindices = -1)
{
//	int bones = (*GrannyGetBlendDagNodeWeightedBlendSkeleton)(mesh);
//	fprintf(f, "bones temp %d\nbones temp\n", bones);
	

	if (nverts == -1)
		nverts = (*GrannyGetMeshVertexCount)(mesh);
	if (nindices == -1)
		nindices = (*GrannyGetMeshIndexCount)(mesh);

	for (int e = 0; e < mesh->PrimaryTopology->Groups_count; e++)
	{

	

		fprintf(f, "fn create = (\ntemp = mesh numverts:%d numfaces:%d\n",
		nverts,
		nindices/3);

		fprintf(f, "setNumTVerts temp %d\nbuildTVFaces temp\n", nverts);

		t_Vertex_PNT332* verts = new t_Vertex_PNT332[nverts];
		(*GrannyCopyMeshVertices)(mesh, GrannyPNT332VertexType, verts);
		for (int i = 0; i < nverts; ++i)
		{
			fprintf(f, "setVert temp %d [%f,%f,%f]\n", i+1,
				verts[i].Position[0], verts[i].Position[1], verts[i].Position[2]);
			fprintf(f, "setTVert temp %d [%f,%f,%f]\n", i+1,
				verts[i].TextureCoordinates0[0], -verts[i].TextureCoordinates0[1], 0.0f);
			fprintf(f, "setNormal temp %d [%f,%f,%f]\n", i+1,
				verts[i].Normal[0], verts[i].Normal[1], verts[i].Normal[2]);


		}
		delete[] verts;

		t_Indices16* indices = new t_Indices16[nindices];

		(*GrannyCopyMeshIndices)(mesh, 2, indices);

		int initIND = mesh->PrimaryTopology->Groups[e].TriFirst;
		int finishIND = (mesh->PrimaryTopology->Groups[e].TriCount)-1;

		int indexIND = mesh->PrimaryTopology->Groups[e].MaterialIndex;

#ifdef _DEBUG
		printf("init: %d, finish. %d, index: %d\n",  initIND, finishIND, indexIND);
#endif
		//for (int i = 0; i < nindices/3; ++i)
		for (int i = initIND; i <  (initIND + finishIND)+1; ++i)
		{
			fprintf(f, "setFace temp %d [%d,%d,%d]\n", i+1,
				indices[i*3+0].Int16+1,
				indices[i*3+1].Int16+1,
				indices[i*3+2].Int16+1);

			//printf("indices %d\n",  nindices*3);

#ifdef _DEBUG
			printf("indices %d\n",  i);
#endif
			//fprintf(f, "setFaceMatID temp %d %d\n", i+1, indexIND);
			//IndexCount = i;
		}


		delete[] indices;

		fprintf(f, "for f = 1 to temp.numfaces do setTVFace temp f (getface temp f)\n");

		fprintf(f, ")\ncreate()\n");

	}

}

#ifdef OutputTextureData
void OutputMaterial(FILE* f, t_Materials* Material); //Prototype
#endif

#ifdef OutputTextureData
void OutputMap(FILE* f, t_Maps Map)
{
	fprintf(f, "  map (\n");
	fprintf(f, "  %s\n", Map.Usage);
	OutputMaterial(f, Map.Map);
	fprintf(f, "  )\n");
}
#endif

#ifdef OutputPixelData
void OutputMIPLevel(FILE* f, t_MIPLevels MIPLevel)
{
	fprintf(f, "  miplevel (\n");
	fprintf(f, "  stride: %d\n", MIPLevel.Stride);
	fprintf(f, "  pixel_count: %d\n", MIPLevel.Pixels_count);
	fprintf(f, "  pixel: ");
	t_Pixels* Current_Pixel = MIPLevel.Pixels;
	for (int i = 0; i < MIPLevel.Pixels_count; i++)
	{
		if (i != 0)
			fprintf(f, ",");
		fprintf(f, "%d", Current_Pixel->UInt8);
		Current_Pixel += sizeof(t_Pixels);
	}
	fprintf(f, "\n");
	fprintf(f, "  )\n");
}
#endif

#ifdef OutputPixelData
void OutputImage(FILE* f, t_Images Image)
{
	for (int i = 0; i < Image.MIPLevels_count; i++)
	{
		OutputMIPLevel(f, Image.MIPLevels[i]);
	}
}
#endif

#ifdef OutputTextureData
void OutputTexture(FILE* f, t_Texture* Texture)
{
	//FIXME: Start using _GrannyConvertPixelFormat to convert to uncompressed BMP?
	if (Texture == NULL)
		return;
	fprintf(f, "  texture (\n");
	fprintf(f, "  fromfilename: %s\n", Texture->FromFileName);
	fprintf(f, "  texturetype: %d\n", Texture->TextureType);
	fprintf(f, "  width: %d\n", Texture->Width);
	fprintf(f, "  height: %d\n", Texture->Height);
	fprintf(f, "  encoding: %d\n", Texture->Encoding);
	fprintf(f, "  subformat: %d\n", Texture->SubFormat);
	fprintf(f, "  BytesPerPixel: %d\n", Texture->Layout.BytesPerPixel);
	fprintf(f, "  ShiftForComponent: [%d,%d,%d,%d]\n", Texture->Layout.ShiftForComponent[0], Texture->Layout.ShiftForComponent[1], Texture->Layout.ShiftForComponent[2], Texture->Layout.ShiftForComponent[3]);
	fprintf(f, "  BitsForComponent: [%d,%d,%d,%d]\n", Texture->Layout.BitsForComponent[0], Texture->Layout.BitsForComponent[1], Texture->Layout.BitsForComponent[2], Texture->Layout.BitsForComponent[3]);
#ifdef OutputPixelData
	for (int i = 0; i < Texture->Images_count; i++)
	{
		OutputImage(f, Texture->Images[i]);
	}
#endif
	fprintf(f, "  )\n");
}
#endif

#ifdef OutputTextureData
void OutputMaterial(FILE* f, t_Materials* Material)
{
	fprintf(f, "material (\n");
	fprintf(f, "material name %s\n", Material->Name);
	for (int i = 0; i < Material->Maps_count; i++)
	{
		OutputMap(f, Material->Maps[i]);
	}
	OutputTexture(f, Material->Texture);
	fprintf(f, ")\n");
}
#endif

void OutputBone(FILE* f, t_Bones Bone)
{
	fprintf(f, "bone (\n");
	fprintf(f, "bone name %s\n", Bone.Name);
	fprintf(f, "bone parentindex: %d\n", Bone.ParentIndex);
    fprintf(f, "bone transform dimensions: %d\n", Bone.Transform.Dimensions);
	fprintf(f, "bone transform origin: [%f,%f,%f]\n", Bone.Transform.Origin.Point[0],Bone.Transform.Origin.Point[1],Bone.Transform.Origin.Point[2]);
	fprintf(f, "bone transform rotation: [%f,%f,%f,%f]\n", Bone.Transform.Rotation.Point[0], Bone.Transform.Rotation.Point[1], Bone.Transform.Rotation.Point[2], Bone.Transform.Rotation.Point[3]);
	fprintf(f, "bone transform scale: [%f,%f,%f,%f,%f,%f,%f,%f,%f]\n", Bone.Transform.Scale[0],Bone.Transform.Scale[1],Bone.Transform.Scale[2],Bone.Transform.Scale[3],Bone.Transform.Scale[4],Bone.Transform.Scale[5],Bone.Transform.Scale[6],Bone.Transform.Scale[7],Bone.Transform.Scale[8]);
	fprintf(f, "bone InverseWorldTransform: [%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f]\n", Bone.InverseWorldTransform[0],Bone.InverseWorldTransform[1],Bone.InverseWorldTransform[2],Bone.InverseWorldTransform[3],Bone.InverseWorldTransform[4],Bone.InverseWorldTransform[5],Bone.InverseWorldTransform[6],Bone.InverseWorldTransform[7],Bone.InverseWorldTransform[8],Bone.InverseWorldTransform[9],Bone.InverseWorldTransform[10],Bone.InverseWorldTransform[11],Bone.InverseWorldTransform[12],Bone.InverseWorldTransform[13],Bone.InverseWorldTransform[14],Bone.InverseWorldTransform[15]);
	fprintf(f, "bone LODError: %f\n", Bone.LODError);
	//FIXME: MISSING STUFF HERE!
	fprintf(f, ")\n");
}

void OutputSkeleton(FILE* f, t_Skeletons* Skeleton)
{
	int bones = (*GrannyGetBlendDagNodeWeightedBlendSkeleton)(Skeleton);
	fprintf(f, "bones temp %d\nbones temp\n", bones);

	fprintf(f, "skeleton bone count %d\n", Skeleton->Bones_count);
	fprintf(f, "skeleton (\n");
	fprintf(f, "skeleton name %s\n", Skeleton->Name);
	for (int i = 0; i < Skeleton->Bones_count; i++)
	{
		//FIXME:
		//OutputBone(f, Skeleton->Bones[i]);
		OutputBone(f, Skeleton->Bones[0]);
	}
	fprintf(f, ")\n");
}

#ifdef OutputTrackGroupData
void OutputTrackGroup(FILE* f, t_TrackGroups* TrackGroup)
{
	fprintf(f, "trackgroup (\n");
	fprintf(f, "trackgroup name %s\n", TrackGroup->Name);
	//FIXME: MISSING STUFF HERE!
	fprintf(f, ")\n");
}
#endif

void OutputAnimation(FILE* f, t_Animations* Animation)
{
	fprintf(f, "animation (\n");
	fprintf(f, "animation name %s\n", Animation->Name);
	fprintf(f, "animation duration: %f\n", Animation->Duration);
	fprintf(f, "animation timestep: %f\n", Animation->TimeStep);
	fprintf(f, "animation oversampling: %f\n", Animation->Oversampling);
	for (int i = 0; i < Animation->TrackGroups_count; i++)
	{
		OutputTrackGroup(f, Animation->TrackGroups[i]);
	}
	fprintf(f, ")\n");
}

int main(int argc, char** argv)
{
	if (argc != 2)
	{
		printf("Please run as something like '%s HC_cathedral.gr2'.\n", argv[0]);
		exit(-1);
	}

	LoadStuff();
	(*GrannySetLogCallback)(&logger);

	char* file = argv[1];
	GrannyFile* modelfile = (*GrannyReadEntireFile)(file);
	if (! modelfile)
	{
		printf("Couldn't read GR2 file '%s' - maybe it's not the right name, or not in the right folder, or an invalid GR2 file.\n", file);
		exit(-2);
	}
	t_FileInfo* modelinfo = (*GrannyGetFileInfo)(modelfile);
	if (! modelfile)
	{
		printf("Couldn't get GR2 FileInfo. I have no idea why.\n");
		exit(-3);
	}


	//Opening also cleans output file
	FILE* f = fopen("output.tmp", "w");
#ifdef OutputTextureData
	printf("Outputting textures...\n");
	for (int i = 0; i < modelinfo->Textures_count; i++)
	{
		OutputTexture(f, modelinfo->Textures[i]);
	}
#endif

	printf("Outputting skeletons...\n");
	for (int i = 0; i < modelinfo->Skeletons_count; i++)
	{
		OutputSkeleton(f, modelinfo->Skeletons[i]);
	}

#ifdef OutputTextureData
	printf("Outputting materials...\n");
	for (int i = 0; i < modelinfo->Materials_count; i++)
	{
		OutputMaterial(f, modelinfo->Materials[i]);
	}
#endif

	//FIXME: To Do: VertexDatas

	//FIXME: To Do: TriTopologies
	
	printf("Outputting meshes...\n");
	for (int i = 0; i < modelinfo->Meshes_count; i++)
	{
		OutputMesh(f, modelinfo->Meshes[i]);
	}

#ifdef OutputTrackGroupData
	printf("Outputting trackgroups...\n");
	for (int i = 0; i < modelinfo->TrackGroups_count; i++)
	{
		OutputTrackGroup(f, modelinfo->TrackGroups[i]);
	}
#endif

	printf("Outputting animations...\n");
	for (int i = 0; i < modelinfo->Animations_count; i++)
	{
		OutputAnimation(f, modelinfo->Animations[i]);
	}
	
	fclose(f);

	rename("output.tmp", "output.ms");

	printf("Created output.ms.\n");

	return 0;	
}
