#define GLI_INCLUDE_WGL_ARB_RENDER_TEXTURE


GLboolean wglBindTexImageARB (void * hPbuffer, GLint iBuffer);

GLboolean wglReleaseTexImageARB (void * hPbuffer, GLint iBuffer);

GLboolean wglSetPbufferAttribARB (void * hPbuffer, const GLint *piAttribList);


