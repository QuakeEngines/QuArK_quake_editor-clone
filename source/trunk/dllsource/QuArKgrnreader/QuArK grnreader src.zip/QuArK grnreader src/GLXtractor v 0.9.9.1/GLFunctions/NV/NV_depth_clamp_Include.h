#define GLI_INCLUDE_NV_DEPTH_CLAMP

enum Main {
  
  GL_DEPTH_CLAMP_NV               = 0x864F,
};

