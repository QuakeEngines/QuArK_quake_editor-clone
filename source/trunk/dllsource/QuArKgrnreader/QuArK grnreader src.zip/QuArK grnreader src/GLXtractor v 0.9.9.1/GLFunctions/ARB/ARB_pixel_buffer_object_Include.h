#define GLI_INCLUDE_ARB_PIXEL_BUFFER_OBJECT

enum Main {

  GL_PIXEL_PACK_BUFFER_ARB                  =  0x88EB,
  GL_PIXEL_UNPACK_BUFFER_ARB                =  0x88EC,


  GL_PIXEL_PACK_BUFFER_BINDING_ARB          =  0x88ED,
  GL_PIXEL_UNPACK_BUFFER_BINDING_ARB        =  0x88EF,
};




