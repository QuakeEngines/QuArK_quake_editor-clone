#define GLI_INCLUDE_NV_TEXTURE_ENV_COMBINE4

enum Main {

  GL_COMBINE4_NV                                  =   0x8503,
  GL_SOURCE3_RGB_NV                               =   0x8583,
  GL_SOURCE3_ALPHA_NV                             =   0x858B,
  GL_OPERAND3_RGB_NV                              =   0x8593,
  GL_OPERAND3_ALPHA_NV                            =   0x859B,

};
