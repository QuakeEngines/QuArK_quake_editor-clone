#define GLI_INCLUDE_ARB_TRANSPOSE_MATRIX



void glLoadTransposeMatrixdARB (const GLdouble m[16] );

void glLoadTransposeMatrixfARB (const GLfloat m[16] );

void glMultTransposeMatrixdARB (const GLdouble m[16] );

void glMultTransposeMatrixfARB (const GLfloat m[16] );



