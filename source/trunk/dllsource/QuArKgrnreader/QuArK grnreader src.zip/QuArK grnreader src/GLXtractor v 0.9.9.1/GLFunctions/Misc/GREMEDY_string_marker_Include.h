#define GLI_INCLUDE_GREMEDY_STRING_MARKER

void glStringMarkerGREMEDY(GLsizei len,const void *string);
