#define GLI_INCLUDE_EXT_PACKED_DEPTH_STENCIL


enum Main {
    
    GL_DEPTH_STENCIL_EXT               =   0x84F9,
    GL_UNSIGNED_INT_24_8_EXT           =   0x84FA,

    GL_DEPTH24_STENCIL8_EXT            =   0x88F0,
    GL_TEXTURE_STENCIL_SIZE_EXT        =   0x88F1,
};

