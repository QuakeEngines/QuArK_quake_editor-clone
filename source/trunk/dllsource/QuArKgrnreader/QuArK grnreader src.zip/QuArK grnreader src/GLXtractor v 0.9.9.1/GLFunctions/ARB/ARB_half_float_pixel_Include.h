#define GLI_INCLUDE_ARB_HALF_FLOAT_PIXEL


enum Main {

  GL_HALF_FLOAT_ARB                =   0x140B,

};


