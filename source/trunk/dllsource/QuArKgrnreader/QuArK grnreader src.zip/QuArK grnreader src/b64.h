#ifndef b64
#define b64

#include <string>

std::string encode( char* instream, int size );

#endif
