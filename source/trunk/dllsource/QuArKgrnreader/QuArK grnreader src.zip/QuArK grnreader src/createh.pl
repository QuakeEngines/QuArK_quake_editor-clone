open STDOUT, '>AutoGranny.h' or die $!;
open D, "dumpbin /exports granny2.dll|" or die $!;
while(<D>){
	if(/ordinal hint RVA/../Summary/){
	chomp;
	if (/[\dA-F]{8} (_(.*)@(.*))/) {

		my @args = 0..$3/4-1;
		$types .= qq[int (__stdcall *_$2) (] . (join ', ', map "int", @args) . qq[);\n];
		
		$load .= qq[\t*(void**)&_$2 = GetProcAddress(GrannyDLL, "$1");\n];
	} elsif (/[\dA-F]{8} (.*)/) {
		$types .= qq[int $1;\n];
		$load .= qq[\t$1 = *(int*)GetProcAddress(GrannyDLL, "$1");\n];
	}
}
}

print <<EOF;
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

$types

void LoadStuff()
{
	HMODULE GrannyDLL = LoadLibrary("granny2.dll");
	assert(GrannyDLL);
$load
}
EOF
