use strict;
use warnings;

sub oob(&);
sub get($);
sub moveto($);
sub skip($);

open G, 'gr2_viewer.exe' or die;

my @types;

moveto 0x5312d8;
for (0..20) {
	my $offset0 = get 'L';
	skip 4;
	my $offset1 = get 'L';
	skip 4;
	oob {
		moveto $offset0;
		my $s = get 'Z*';
		if (!$s or $s =~ /^void/) {
			moveto $offset1;
			$s = "$s /* ".(get 'Z*')." */";
		}
		push @types, $s;
	};
}
$types[0] = 'EndMember';
$types[1] = 'InlineMember';

#print join "\n", @types;

my %structs;
my @struct_order;

#push @struct_order, 5533528; # HACK

my $root = 0x52b128;
push @struct_order, $root;
$structs{$root}{ref} = ["FileInfo"];
$structs{$root}{code} = read_struct($root);

my @rawkeys;
{
	my %s;
	@s{reverse @struct_order} = reverse 0..$#struct_order;
	@rawkeys = sort { (keys %{$structs{$a}{depends}} <=> keys %{$structs{$b}{depends}}) or ($s{$a} <=> $s{$b}) } keys %structs;	
}

my @keys = @rawkeys;
=pod
while (@rawkeys) {
	my $i = 0;
	while ($i < @rawkeys) {
		my $s = $rawkeys[$i];
		warn "$s: ", join(', ', keys %{$structs{$s}{depends}}), "\n" if $structs{$s}{depends};
		if (1) {
			push @keys, splice @rawkeys, $i, 1;
		} else {
			++$i;
		}
	}	
}
warn join ", ", @keys;
=cut

for my $s (@keys) {
	my @r = unique(@{$structs{$s}{ref}});
	if (@r == 1) {
		print "struct t_$r[0];\n";
	} else {
		print "struct t_$s;\n";
		for (@r) {
			print "typedef struct t_$s t_$_;\n";
		}
	}
	print "\n";
}

for my $s (@keys) {
	my @r = unique(@{$structs{$s}{ref}});
	if (@r == 1) {
		print "struct t_$r[0] {\n$structs{$s}{code}};\n";
	} else {
		print "struct t_$s {\n$structs{$s}{code}};\n";
#		for (@r) {
#			print "typedef struct t_$s t_$_;\n";
#		}
	}
	print "\n";
}

sub read_struct {
	my ($off) = @_;
	moveto $off;
	my $r = '';
	while (1) {
		my $type_num = get 'L';
		my $name_offset = get 'L';
		my $sub_offset = get 'L';
		my $count = get 'L';
		skip(4*4);
		last if $type_num == 0;
	
		my $type = $types[$type_num];

		my $name = oob { moveto($name_offset); get('Z*') };
		
		next if $name =~ /^_/; # avoid _GrannyFileStringTable

		my $n = $name.($count?"[$count]":"");

		if ($type =~ /ReferenceToArrayMember/) {
			$r .= "\tt_$name * $n;\n";

		} elsif ($type =~ /InlineMember/) {
			$r .= "\tt_$name $n;\n";
			$structs{$off}{depends}{$name} = 1;

		} elsif ($type =~ /(VariantReferenceMember)/) {
			$r .= "\tgranny_int32 $name\_count;\n";
			$r .= "\tt_$name ** $n; /* $1 */\n";

		} elsif ($type =~ /(ArrayOfReferencesMember)/) {
			$r .= "\tgranny_int32 $name\_count;\n";
			$r .= "\tt_$name * $n; /* $1 */\n";

		} elsif ($type =~ /(StringMember)/) {
			$r .= "\tt_StringMember * $name\_strings; /* $1 */\n";
			$r .= "\tgranny_int32 $name\_count;\n";
			$r .= "\tvoid * $name;\n";

		} else {
			$r .= "\t$type $n;\n";
		}
		
		if ($sub_offset) {
			push @struct_order, $sub_offset;
			$structs{$sub_offset}{ref} ||= [];
			push @{$structs{$sub_offset}{ref}}, $name;
 			if (not $structs{$sub_offset}{code}) {
 				$structs{$sub_offset}{code} = -1;
				$structs{$sub_offset}{code} = oob { read_struct($sub_offset); };
			}
		}
	}
	$r;
}

sub oob(&) {
	my $h = tell G;
	my $r = $_[0]();
	seek G, $h, 0;
	return $r;
}

sub get($) {
	my $d;
	if ($_[0] eq 'Z*') {
		oob { read G, $d, 1024 };
		my $str = unpack 'Z*', $d;
		skip(length $str);
		return $str;
	} else {
		read G, $d, length(pack $_[0], 0);
		return unpack $_[0], $d;	
	}
}

sub moveto($) {
	seek G, c($_[0]), 0;	
}

sub skip($) {
	seek G, $_[0], 1;
}

sub c {
	$_[0] - 0x400000;
}

sub unique {
	my %u; @u{@_} = (); sort keys %u;
}