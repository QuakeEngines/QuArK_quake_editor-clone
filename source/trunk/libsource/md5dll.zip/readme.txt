MD5 DLL FOR GAME MAKER
----------------------

If you encounter bugs or you know better way to do something, 
please visit in: http://forums.gamemaker.nl/index.php?showtopic=105414
or just send me PM.


Changes
-------

Version 0.2c
- Fixed stupid bug in GetStringMd5 function. Thanks to Tom DUTCH to pointing this out

Version 0.2
- New MD5 sources (fix: correct for loop used to replace memset, exceeded bounds)
- Two new functions benchmark MD5 and random MD5
- Reduced dll size

Version 0.1
- First release