========================================================================
       CONSOLE APPLICATION : UnitTest
========================================================================


This file contains a summary of what you will find in each of the files that
make up your UnitTest application.

UnitTest.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

UnitTest.cpp
    This is the main application source file.


/////////////////////////////////////////////////////////////////////////////
This program allows to see how each interface method can be used in openIL

NOTE: This program depends on cppunit, which can be found on Sourceforge.net. 
      Currently this test several routines in ILTest.
 
      It runs the test on the shell and reports its results.


