//-----------------------------------------------------------------------------
//
//  $Logfile:: /Code/DLLs/game/ipfilter.h                                    $
// $Revision:: 3                                                              $
//     $Date:: 10/13/03 8:54a                                                 $
//
// Copyright (C) 1999 by Ritual Entertainment, Inc.
// All rights reserved.
//
// This source is may not be distributed and/or modified without
// expressly written permission by Ritual Entertainment, Inc.
//
//
// DESCRIPTION:
//

#ifndef __IPFILTER_H__
#define __IPFILTER_H__

#include "g_local.h"

qboolean SV_FilterPacket( const char *from );

#endif /* !__IPFILTER_H__ */
