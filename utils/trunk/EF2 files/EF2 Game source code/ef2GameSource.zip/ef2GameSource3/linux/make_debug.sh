make build_debug
cp debugi386-glibc/linuxef2ded ../../../GAME/
cp debugi386-glibc/ef2gamei386.so ../../../GAME/
