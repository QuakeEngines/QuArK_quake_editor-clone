make build_release
cp releasei386-glibc/linuxef2ded ../../../GAME/
cp releasei386-glibc/ef2gamei386.so ../../../GAME/
