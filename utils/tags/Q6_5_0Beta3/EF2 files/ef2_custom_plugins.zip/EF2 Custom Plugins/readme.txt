README FILE
===========================================================
Title :EF2 3d modeling plugins
Version :1.0
Author :FHL34
Release Date :01-01-2007

===========================================================

thot it woulth by nice to have all the plugins thogether for EF2

 neil davis senkusha 3d max script SKBimporter_BETA 
 neil davis senkusha 3d max script sklexporter
 neil davis senkusha 3d max script tanimporter
 paul milkshape tan exporter
 Chris Graham ef2 importer
 Chris Graham the source code for importer and exporter (exporter not finischt) 

===============================================================================