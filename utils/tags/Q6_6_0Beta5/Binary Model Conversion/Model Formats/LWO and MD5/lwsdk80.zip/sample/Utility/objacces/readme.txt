ObjectAccess Plug-in Source


The objacces.c sample is the source code for the objacces.p plug-in
included with versions of LightWave prior to 6.0.  This is offered in
as-is condition for the edification of programmers who've used it in
the past.  It may not be the best teaching example, since the source
wasn't written with that in mind, and it hasn't been modified yet to
handle the new object format used by LightWave 6.0.

The source requires the lwobjacc.h header file provided with earlier
versions of the SDK.

Thanks to Arnie Cachelin for providing the source code.


Ernie Wright
27 Jan 00


----------------------------------------------------------------------
Fixed a bug in createUVs().

EW 28 Jan 00
