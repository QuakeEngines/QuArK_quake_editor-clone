/*
 * pts_rand.h - Declarations for Mersenne Twister (MT19937) random number 
 *              generator
 */

extern void sgenrand(unsigned long);
extern unsigned long genrand();
