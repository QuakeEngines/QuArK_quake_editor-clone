/*
 * pts_gui.c - Callbacks for the procedural texture interface 
 */

#include "pts_gui.h"
#include "pts_incs.h"

extern LWXPanelFuncs    *xpfunc;


/*
 * Destroy() NonModal XPanel Interface Callback.
 *
 * The following routine is required for Nonmodal type panels.
 */
void
OPTS_view_destroy ( void *myData )
{

//	INSTData *inst = (INSTData*)myData;

  return;
}

