#define _MACOS
#define LWMAC
#define RELEASE
#define MAC_OS_X
#define ACCESSOR_CALLS_ARE_FUNCTIONS 1
#define OPAQUE_TOOLBOX_STRUCTS 1
#define TARGET_API_MAC_CARBON 1

#pragma old_argmatch on
