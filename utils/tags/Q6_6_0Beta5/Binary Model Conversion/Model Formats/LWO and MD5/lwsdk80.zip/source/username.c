/*
 * LWSDK Library Source File
 * Copyright 1995,1997  NewTek, Inc.
 *
 * The default 'UserNames' array is empty, so the user name will be
 * the same as the server name for a minimal server.
 */
#include <lwserver.h>


    ServerUserName
UserNames[] = {
    { 0 }
};

