/*
 * LWSDK Library Source File
 * Copyright 1995,1997  NewTek, Inc.
 *
 * Default 'Shutdown' implementaion does nothing.
 */
#include <lwserver.h>


    void
Shutdown (
    void                    *serverData)
{
}
