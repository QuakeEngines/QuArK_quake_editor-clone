md5importer-0.5.py
2006-02-20
Imports animated characters from MD5 (Doom3 engine format) into Blender
By Bob Holcomb and Thomas "der_ton" Hutter


Legal Stuff:
************
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



Where to get the latest version:
********************************
http://www.doom3world.org/ (there is a Blender section there)
http://home.tiscali.de/der_ton/blender-md5importer.rar



How to use:
***********

Start the script, select the md5mesh and md5anim file and press "Import".
You can leave either the md5mesh or md5anim field blank.
If you leave the md5mesh field blank, the animation will be applied to
the selected armature. If no armature is selected, the animation will
be applied to the first armature in the scene.

It is not recommended to import an animation on an armature that already
has an action.
