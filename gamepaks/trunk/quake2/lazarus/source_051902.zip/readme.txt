Lazarus source code
Version 2.105
05/19/02

The end. It has been a fun ride, but this will most likely be the last update I make to
Lazarus. This zip includes all source code needed to build the Lazarus gamex86.dll, version
2.105, including the previously-omitted 3dfx header files you'll need for glide fog.

The code compiles fine with MSVC 6.0, and should also work with no problems with MSVC 5.0.
I make no guarantees of success with any other compiler. If you insist on lcc, hey that's
your problem, bub :-)

Use to your heart's content any way you see fit, subject to id's original license agreement.
If you use this to make money, it won't be me you need to worry about but somebody with
just a bit more clout. If you *do* use any of this in a publicly-released mod, I'd 
appreciate a link to the Lazarus site, currently http://planetquake.com/lazarus.


David Hyde
rascal@vicksburg.com


