# mat1.py - process materials

import os
from get_tokens import *

def shortName(s):
    result = s
    q = s.find(".")
    if q != -1:
        result = s[:q]
    return result

dirname = "c:\\rowdy\\doom3\\base\\materials"

names = os.listdir(dirname)
names.sort()

nested = 0
material_name = "undefined"
kount = 0

o = open('d3_materials.txt', 'w')

o.write('  Textures.qtx =\n')
o.write('  {\n')
o.write('    Toolbox = "Texture Browser..."\n')
o.write('    Root = "D3 Materials.qtxfolder"\n')
o.write('\n')
o.write('    // Notice! The b="<filename>" specifies which materials file the material exists in\n')

# calculate the longest material filename so we can pad the incl lines
# to make it look nice
longestName = 0
for name in names:
    if len(name) > longestName:
        longestName = len(name)
longestName += 14

for name in names:
    s = 't_d3material_%s:incl' % shortName(name)
    while len(s) < longestName:
        s += ' '
    o.write('    %s = { a="base" b="%s.mtr" }\n' % (s, shortName(name)))
o.write('\n')
o.write('    D3 Materials.qtxfolder =\n')
o.write('    {\n')

#o.write('      Base_Button.txlist =\n')
#o.write('      {\n')
#o.write('        base_button/shootme2.wl    = { t_d3shader_base_button=! }\n')
#o.write('      }\n')

#o.write('      Base_Door.txlist =\n')
#o.write('      {\n')
#o.write('        base_door/shinymetaldoor.wl               = { t_d3shader_base_door=! }\n')
#o.write('        base_door/shinymetaldoor_outside.wl       = { t_d3shader_base_door=! }\n')
#o.write('        base_door/shinymetaldoor_outside3a2.wl    = { t_d3shader_base_door=! }\n')
#o.write('      }\n')

for name in names:
    print "processing file: %s" % name

    o.write('      mtr_%s.txlist =\n' % shortName(name))
    o.write('      {\n')

    tokens = getTokens(dirname + "\\" + name)
    iToken = iter(tokens)
    tokenType, tokenValue = iToken.next()
    #print "%s/%s" % (str(tokenType), str(tokenValue))
    while tokenType != T_EOF:
        if (tokenType == T_SPECIAL) and (tokenValue == "{"):
            # this is the start of a new material
            nested = 1
            print "    processing material: %s" % material_name
            kount += 1
            while nested > 0:
                tokenType, tokenValue = iToken.next()
                if tokenType == T_EOF:
                    break
                if (tokenType == T_SPECIAL) and (tokenValue == "{"):
                    nested += 1
                elif (tokenType == T_SPECIAL) and (tokenValue == "}"):
                    nested -= 1
            #print "    -- end of material"

            # for now, ignore anything that does not start with 'textures/'
            if material_name.startswith('textures/'):
                o.write('        %s.wl    = { t_d3material_%s=! }\n' % (material_name[9:], shortName(name)))

        if tokenType == T_IDENTIFIER:
            material_name = tokenValue

        tokenType, tokenValue = iToken.next()

    o.write('      }\n')

print "found %d materials" % kount

o.write('    }\n')
o.write('  }\n')

o.close()

"""
  Textures.qtx =
  {
    Toolbox = "Texture Browser..."
    Root = "DO NOT USE Q3 shaders.qtxfolder"

    // Notice! The b="<filename>" specifies which shaderfile the shader exists in
    t_d3shader_base_button:incl         = { a="base" b="base_button.shader" }
    t_d3shader_base_door:incl           = { a="base" b="base_door.shader" }

    DO NOT USE Q3 shaders.qtxfolder =
    { // still need to figure where the stuff below really goes!! Maleficus!
      Base_Button.txlist =
      {
        base_button/shootme2.wl    = { t_d3shader_base_button=! }
      }
      Base_Door.txlist =
      {
        base_door/shinymetaldoor.wl               = { t_d3shader_base_door=! }
        base_door/shinymetaldoor_outside.wl       = { t_d3shader_base_door=! }
        base_door/shinymetaldoor_outside3a2.wl    = { t_d3shader_base_door=! }
      }
    }
  }
"""

