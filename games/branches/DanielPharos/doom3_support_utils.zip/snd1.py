# snd1.py - process sound files

import os.path

def visit(arg, dirname, names):
    print dirname

    sounds = []
    for name in names:
        if name.endswith('.ogg'):
            sounds.append(name)

    if len(sounds) > 0:
        tmpname = dirname[dirname.find('sound') + 6:]
        tmpname = tmpname.replace('/', '_').replace('\\', '_')

        dirprefix = dirname[dirname.find('sound'):]
        dirprefix = dirprefix.replace('\\', '/')

        o.write('      noise: =\n')
        o.write('      {\n')
        o.write('        typ = "C"\n')
        o.write('        txt = "%s"\n' % tmpname)

        o.write('        items =\n')
        first = 1
        for sound in sounds:
            head, tail = os.path.split(sound)
            root, ext = os.path.splitext(tail)
            if first == 1:
                first = 0
            else:
                o.write('$0D\n')
            o.write('          "%s"' % root)
        o.write('\n')

        o.write('        values =\n')
        first = 1
        for sound in sounds:
            if first == 1:
                first = 0
            else:
                o.write('$0D\n')
            o.write('          "%s/%s"' % (dirprefix, sound))

        o.write('\n')
        o.write('      }\n')

o = open('snd1.txt', 'w')
o.write('    t_noise:incl =\n')
o.write('    {\n')
o.write('      noise: =\n')
o.write('      {\n')
o.write('        Txt = " "\n')
o.write('        Typ = "B"\n')
o.write('        Cap = "sounds..."\n')
o.write('        form = "t_noise_form:form"\n')
o.write('        hint = "Available sound files"\n')
o.write('      }\n')
o.write('    }\n')
o.write('\n')
o.write('    t_noise_form:form =\n')
o.write('    {\n')

os.path.walk('/rowdy/doom3/base/sound', visit, None)

o.write('    }\n')

o.close()

"""
// a cool sound menu for all of the default Q3 sounds!!!-Maleficus
      noise: =
      {
        typ = "C"
        txt = "Feedback"
        items = "1_frag"$0D
		    "1_minute"$0D
		    "2_frags"$0D
		    "Two"
        values =
		    "/sound/feedback/1_frag.wav"$0D
		    "/sound/feedback/1_minute.wav"$0D
		    "/sound/feedback/2_frags.wav"$0D
            "/sound/feedback/two"
      }
      noise: =
      {
		typ = "C"
		txt = "Movers"
        items =
		"Doors: Dr1_end"$0D
		"Doors: Dr1_strt"$0D
		"Switches: Butn2"
        values =
		"/sound/movers/doors/dr1_end.wav"$0D
		"/sound/movers/doors/dr1_strt.wav"$0D
		"/sound/movers/switches/butn2.wav"
      }
"""

