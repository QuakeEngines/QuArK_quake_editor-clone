# tex1.py - process the texture list (from the QuArK addon)

i = open("d3tex2.qrk")
o = open("tex1.txt", "w")
while 1:
    s = i.readline()
    if s == "":
        break
    s = s.replace("\n", "").replace("\r", "")
    if s.endswith(".wl ="):
        s = s.strip()
        lbrace = i.readline().replace("\n", "").replace("\r", "").strip()
        name = i.readline().replace("\n", "").replace("\r", "").strip()
        rbrace = i.readline().replace("\n", "").replace("\r", "").strip()

        # change to shortcut (not really correct, but anyway ...)
        if name == 'a = "base"':
            name = 't_d3=!'

        # nope, doesn't seem to want to work
        #if s.startswith("alphalabs/") and (name == 'a = "base"'):
        #    s = s[10:]
        #    name = 't_d3als=!'


        """
    t_d3bds:incl = { a = "base" b = "base_door" }
    t_d3bfs:incl = { a = "base" b = "base_floor" }
    t_d3bls:incl = { a = "base" b = "base_light" }
    t_d3bts:incl = { a = "base" b = "base_trim" }
    t_d3bws:incl = { a = "base" b = "base_wall" }
    t_d3cas:incl = { a = "base" b = "caves" }
    t_d3cos:incl = { a = "base" b = "common" }
    t_d3des:incl = { a = "base" b = "decals" }
    t_d3dys:incl = { a = "base" b = "dynamic" }
    t_d3eds:incl = { a = "base" b = "editor" }
    t_d3ens:incl = { a = "base" b = "enpro" }
    t_d3gls:incl = { a = "base" b = "glass" }
    t_d3hes:incl = { a = "base" b = "hell" }
    t_d3ics:incl = { a = "base" b = "ice" }
    t_d3kts:incl = { a = "base" b = "ktest" }
    t_d3las:incl = { a = "base" b = "lab" }
    t_d3mcs:incl = { a = "base" b = "mcity" }
    t_d3mos:incl = { a = "base" b = "morgue" }
    t_d3obs:incl = { a = "base" b = "object" }
    t_d3ous:incl = { a = "base" b = "outside" }
    t_d3pas:incl = { a = "base" b = "particles" }
    t_d3rfs:incl = { a = "base" b = "recyc_floor" }
    t_d3rws:incl = { a = "base" b = "recyc_wall" }
    t_d3ros:incl = { a = "base" b = "rock" }
    t_d3sxs:incl = { a = "base" b = "sfx" }
    t_d3sks:incl = { a = "base" b = "skies" }
    t_d3was:incl = { a = "base" b = "washroom" }
        """


        # ignore textures that are obvious bumpmaps (or similar)
        # textures with "dif" at the end of the name have freaky side-effects
        #if (s.find("_local.wl")  != -1) or \ # normal map
        #   (s.find("_s.wl")      != -1) or \ # specular map
        #   (s.find("_d.wl")      != -1) or \ # diffuse map
        #   (s.find("_bmp.wl")    != -1) or \ # bump map
        #   (s.find("_add.wl")    != -1) or \ # something
        #   (s.find("_b.wl")      != -1) or \ # something
        #   (s.find("_color.wl")  != -1) or \ # something
        #   (s.find("_shadow.wl") != -1) or \ # something
        #   (s.find("dif.wl")     != -1):
        if (s.find("_local.wl")  != -1) or \
           (s.find("_s.wl")      != -1) or \
           (s.find("_d.wl")      != -1) or \
           (s.find("_bmp.wl")    != -1) or \
           (s.find("_add.wl")    != -1) or \
           (s.find("_b.wl")      != -1) or \
           (s.find("_color.wl")  != -1) or \
           (s.find("_shadow.wl") != -1) or \
           (s.find("dif.wl")     != -1):
            prefix = "// "
        else:
            prefix = ""

        o.write("          %s%s %s %s %s\n" % (prefix, s, lbrace, name, rbrace))
    else:
        # some minimal translations ;-)
        if s.find('Root = "New Folder.qtxfolder"') != -1:
            o.write('        Root = "id Software Textures.qtxfolder"\n')
        elif s.find('New Folder.qtxfolder =') != -1:
            o.write('        t_d3:incl = { a = "base" }\n')
            o.write('\n')
            o.write('        id Software Textures.qtxfolder =\n')
        else:
            o.write("%s\n" % s)
o.close()
i.close()

