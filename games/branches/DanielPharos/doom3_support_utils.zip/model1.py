# model1.py - create an addon for models

import os.path

def visit(arg, dirname, names):
    print dirname

    models = []
    for name in names:
        if name.endswith('.lwo'):
            models.append(name)

    if len(models) > 0:
        models.sort()
        tmpname = dirname[dirname.find('models') + 7:]
        tmpname = tmpname.replace('/', '_').replace('\\', '_')

        dirprefix = dirname[dirname.find('models'):]
        dirprefix = dirprefix.replace('\\', '/')

        o.write('      model: =\n')
        o.write('      {\n')
        o.write('        typ = "C"\n')
        o.write('        txt = "%s"\n' % tmpname)

        o.write('        items =\n')
        first = 1
        for model in models:
            head, tail = os.path.split(model)
            root, ext = os.path.splitext(tail)
            if first == 1:
                first = 0
            else:
                o.write('$0D\n')
            o.write('          "%s"' % root)
        o.write('\n')

        o.write('        values =\n')
        first = 1
        for model in models:
            if first == 1:
                first = 0
            else:
                o.write('$0D\n')
            o.write('          "%s/%s"' % (dirprefix, model))

        o.write('\n')
        o.write('      }\n')

o = open('model1.txt', 'w')
o.write('    t_model_form:form =\n')
o.write('    {\n')

os.path.walk('/rowdy/doom3/base/models', visit, None)

o.write('    }\n')

o.close()

"""
      model: =
      {
        typ = "C"
        txt = "Ammo"
        items = "grenade1.md3"$0D
                "rocket/rocket.md3"
        values = "/models/ammo/grenade1.md3"$0D
                 "/models/ammo/rocket/rocket.md3"
      }
"""

