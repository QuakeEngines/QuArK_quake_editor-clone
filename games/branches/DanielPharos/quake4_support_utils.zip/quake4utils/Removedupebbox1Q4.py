# bbox1.py - try to remove duplicate bounding boxes from the DataQ4_bbox.qrk file

import os, os.path

i = open("c:\\cdunde\\quake4\\DataQ4_bbox.qrk")
o = open("c:\\cdunde\\quake4\\DataQ4_FIXbbox.qrk", "w")

foundForms = 0
entitiesDone = []
startsearch = 0
bboxcount = 0

while 1:
    s = i.readline()

    if (s.find(":form") != -1):
        startsearch = 1

    if startsearch == 1:
        if s.startswith("      bbox ="):
            bboxcount = bboxcount + 1

    if bboxcount == 2:
        startsearch = 0
        bboxcount = 0
        continue

    if s.startswith("    }"):
        startsearch = 0
        bboxcount = 0

    o.write(s)

    if s == '':  # reached end of file
        break

o.close()
i.close()

