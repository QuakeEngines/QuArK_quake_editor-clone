# checktex.py - it is suspected that mappers should not use textures, but should just
#               use materials.  This script attempts to check if there are any textures
#               that are not refereced from materials

import os.path

def visit(arg, dirname, names):
    global textures
    print '    %s' % dirname
    for name in names:
        if name.endswith('.tga'):
            fullname = os.path.join(dirname, name).replace('\\', '/')
            partname = fullname[20:]
            textures.append(partname)

textures = []
print 'reading textures ...'
os.path.walk('c:/cdunde/quake4/q4base/textures', visit, None)
print 'found %d textures' % len(textures)
print

print 'reading materials ...'
materialPath = 'c:/cdunde/quake4/q4base/materials'
materialTextures = []
names = os.listdir(materialPath)
for name in names:
    if name.endswith('.mtr'):
        print '    %s' % name
        i = open(os.path.join(materialPath, name))
        while 1:
            s = i.readline()
            if s == '':
                break
            # lots of replaces so we don't have to fully parse the material files
            s = s.replace(chr(9), ' ')
            s = s.replace('(textures', '( textures')
            s = s.replace(',', ' ')
            s = s.replace('doom/base/textures', ' textures')
            s = s.replace('tga)', 'tga )')
            s = ' '.join(s.split())
            c = s.split(' ')
            # it seems that sometimes the texture lacks the '.tga' suffix
            if (len(c) == 2) and (c[0] in ['qer_editorimage', 'bumpmap', 'diffusemap', 'specularmap']) and not(c[1].endswith('.tga')):
                # treat c[1] as if it were a texture
                cc = c[1] + '.tga'
                cc = cc.replace('\\', '/')
                if not(cc in materialTextures):
                    #print '    %s' % cc
                    materialTextures.append(cc)
            else:
                for cc in c:
                    if cc.startswith('textures') and cc.endswith('.tga'):
                        cc = cc.replace('\\', '/')
                        if not(cc in materialTextures):
                            #print '    %s' % cc
                            materialTextures.append(cc)
                    elif cc.find('tga') != -1:
                        print '        %s' % cc
        i.close()

print 'found %d textures references in materials' % len(materialTextures)
print

kount = 0
print 'the following textures are not referenced in any materials:'
for texture in textures:
    if not(texture in materialTextures):
        print '    %s' % texture
        kount += 1
print 'there are %d of them' % kount
print

kount = 0
print 'the following material texture references are invalid:'
for materialTexture in materialTextures:
    if not(materialTexture in textures):
        print '    %s' % materialTexture
        kount += 1
print 'there are %d of them' % kount
print

"""
reading textures ...
found 5108 textures

reading materials ...
found 6768 textures references in materials

the following textures are not referenced in any materials:
there are 1458 of them
the following material texture references are invalid:
there are 3118 of them
"""

"""
reading textures ...
found 5108 textures

reading materials ...
found 7751 textures references in materials

the following textures are not referenced in any materials:
there are 987 of them

the following material texture references are invalid:
there are 3630 of them
"""

"""
reading textures ...
found 5108 textures

reading materials ...
found 9277 textures references in materials

the following textures are not referenced in any materials:
there are 161 of them

the following material texture references are invalid:
there are 4330 of them
"""

