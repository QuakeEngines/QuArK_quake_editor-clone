#! /usr/bin/env python

# To run this file change the "Command Prompt" to this files locaiton and copy this:
# E:\Python22\python entdefQ4_2qrk.py
# into its window (without the # symbol) and press ender.

import string, htmlentitydefs, time, os, sys

# globals:
#bboxsize = ""
#dupebboxsize = 1
#bboxmin = ""
#bboxmax = ""

#### Start of input setting requirements and options ####

			# Put an abriviation or name of the game in the quotes
                        # that you want to crate an entities list for.

gameentities = "Quake4"



			# Put the file you want to convert in this folder and
			# its name in the quotes. Or if you use a path location
			# you MUST use forward slashes "/" to avoid a possible error.

inputfile = "C:/Documents and Settings/cdunde1/Desktop/Quake4 def/work/test_slimy_transfer_mocap.def"



			# You can create a QuArK Entities sub-folder by placing a name
                        # for the sub-folder in the quotes.

entitiessubfolder = "work"



                        # Enter a "key word" (like editor_usage) that gives the entity's description.
                        # If you can not find a key word then just leave this    description = ""

description = "editor_usage"



                        # Put the name that gives the size of the entities bounding box here.
                        # If you can not find a name then just leave this    bboxname = ""

bboxname = "size"



			# You can remove "Specific" item "types" by adding their
                        #   "key" name (which usually has a "_" after it) to this list.
                        # For example: take the item editor_color, adding its key name
                        #   "editor" will cause ALL item types with the key name "editor"
                        #   to be skipped or removed.
                        # Each item MUST be in SINGLE quotes followed by a comma except
                        #   for the last item which does not take a comma, as shown.
removespecifics = [
'mins',
'maxs',
'editor',
'dbTitle',
'dbText',
'dbFilter'
                  ]


addspecifics = [
'origin = "0 0 0"',
'angle = "360"'
               ]

#### End of input setting requirements and options ####

inputfile = string.replace(inputfile, "\\", "/") # Converts \ to /

text = "" # This is a temporary place in memory to copy an existing file's data to and
          # add to it, or write new entity data to for making an new file later.

def InputFileName(inputfile):
    words = string.split(inputfile, "/") # Breaks the path into a list of words w/o /
  #  print words
    cmdline = words [-1] # Gets the last word which is the input file name.
  #  print cmdline
    words = string.split(cmdline, ".") # Breaks the file name into words w/o "."
  #  print words
    name =  words[0] # Gets the first file name only as a list item
  #  print name
    name = string.replace(name, " ", "") # Gets the file name out of the list
  #  print name
    path_to_program = words [ 0 : -1 ] # Breaks the path into a list of words w/o /
                                       # and w/o the file name at the end.
  #  print path_to_program
    currentdir = string.join(path_to_program, "/") # Puts path back togeather with /
                                                   # BUT w/o the file name at the end.
  #  print currentdir
    return name

def EntitiesLayout(entitylist):
        "This is the actual entity file writing format for QuArK"
        print entitylist
        if entitylist == []: return
        switch_on = 0
        entityname = 0
        count = 0
        descname = ""
        desccount = 0
        descitem = ""
        descdetailcount = 0
        descdetail = ""
        for item in entitylist:

            if item.startswith('this can'): continue

            if item == ' ': continue

            if item == description:
                descname = item
                desccount = 1
                continue

            if desccount == 1:
                item = string.replace(item,'.','')  # Removes all periods. (not good)
                item = string.replace(item,'*','')  # Removes all asterisk.  (may not be good)
                item = string.replace(item,'\\n','') # Removes all linefeeds.
                item = string.replace(item,'\\','')  # Removes all remaining backslashes.
                descitem = item
                desccount = 0
                descdetailcount = 1
                continue

                     # This section Bypasses all detail description.
            if descdetailcount == 1:
                if item == ' \\' or item == '\\':
                    descdetailcount = 2
                    continue  # Bypasses double backslashes.

            if descdetailcount == 2:
                if item == ' \\' or item == '\\' or item == '\\n':
                    continue
                elif item == "spawnclass" or item == "inherit" or item == "start_open":
                    descdetailcount = 0
                else:
                    continue


                     # This section splits up the "key" name to remove
                     # items given in the removespecifics list above.
            test = item
            splitline = string.split(test,'_')
            for word in splitline:
                for remove in removespecifics:
                    if  word == remove:
                        splitname = 0
                        count = 2
                        break

            if count > 0:
                count = count - 1
                continue

            if item == ' ':
                continue
            if len(item) > 2:
                if item == ' //':
                    count = 1
                    continue
                if item[0] == '/' and item[1] == '/':
                    continue
                if item[0] == ' ' and item[1] == '/' and item[2] == '/':
                    continue

               # Below writes the hard coded entity specifics,
               #    (which may be its name as the description, capitalized and split),
               #    adds the addspecifics list given above to the entity specifics
               #    and writes the right curly bracket of the entity that ends it all.
            if item == "}":
                entityname = 0
                count = 0
                capname = string.capitalize(savename) # Item's first letter gets capitalized.
                savename = string.replace(capname,'_',' ') # Replaces _ with a space.


                if entitiessubfolder == "":
                    if descname == "":
                        outfileEL.write("          ;desc = \""+savename+".\"\n")
                        descname = ""
                        desccount = 0
                        descitem = ""
                        descdetailcount = 0
                        descdetail = ""
                    else:
                        if descitem == "None" or descitem.startswith('#str_'):
                            outfileEL.write("          ;desc = \""+savename+".\"\n")
                        else:
                            outfileEL.write("          ;desc = \""+descitem+".\"\n")
                        if descdetail == "":
                            pass
                        else:
                            outfileEL.write("              "+descdetail+"\n")

                        descname = ""
                        desccount = 0
                        descitem = ""
                        descdetailcount = 0
                        descdetail = ""

                    for add in addspecifics:
                        outfileEL.write("          ")
                        outfileEL.write(add)
                        outfileEL.write("\n")
                    outfileEL.write("        "+item+"\n")

                else:
                    if descname == "":
                        outfileEL.write("            ;desc = \""+savename+".\"\n")
                        descname = ""
                        desccount = 0
                        descitem = ""
                        descdetailcount = 0
                        descdetail = ""
                    else:
                        if descitem == "None" or descitem.startswith('#str_'):
                            outfileEL.write("          ;desc = \""+savename+".\"\n")
                        else:
                            outfileEL.write("          ;desc = \""+descitem+".\"\n")
                        if descdetail == "":
                            pass
                        else:
                            outfileEL.write("              "+descdetail+"\n")

                        descname = ""
                        desccount = 0
                        descitem = ""
                        descdetailcount = 0
                        descdetail = ""

                    for add in addspecifics:
                        outfileEL.write("            ")
                        outfileEL.write(add)
                        outfileEL.write("\n")
                    outfileEL.write("          "+item+"\n")

                break  # Everything is finished for one entity now it goes back for another one.

               # Below causes us to skip over the key word 'entityDef', not needed now.
            if item == entitylist[0]:
                continue
               # Below causes us to skip over the bboxname item, its only used in its "form" section.
            if item == bboxname:
                count = 1
                continue
               # Below writes the entity name and adds the ':e =' to it.
            if item == entitylist[1] and entityname == 0:
                if entitiessubfolder == "":

                    if item.endswith('{'):
                        item = string.replace(item,'{','')
                        outfileEL.write("        "+item+":e =\n")
                        outfileEL.write("        {\n")
                        switch_on = 1

                    else:

                        outfileEL.write("        "+entitylist[1]+":e =\n")
                else:

                    if item.endswith('{'):
                        item = string.replace(item,'{','')
                        outfileEL.write("          "+item+":e =\n")
                        outfileEL.write("          {\n")
                        switch_on = 1

                    else:

                        outfileEL.write("          "+entitylist[1]+":e =\n")
                entityname = 1
                savename = item
                continue
               # Below writes the left curly bracket.
            if item == entitylist[2] and switch_on == 0:
                if entitiessubfolder == "":
                    outfileEL.write("        "+entitylist[2]+"\n")
                else:
                    outfileEL.write("          "+entitylist[2]+"\n")
                switch_on = 1
                continue
               # Below switch_on causes it to write the name of the specific.
            if switch_on == 1:
                if entitiessubfolder == "":
                    outfileEL.write("          "+item+" = ")
                else:
                    outfileEL.write("            "+item+" = ")
                switch_on = 0
                continue
               # Below switch_on causes it to write the specific setting value.
            if switch_on == 0:
                outfileEL.write("\""+item+"\"\n") # This puts the value in double quotes.
                switch_on = 1                     #  and adds a line return.
                continue

        WriteForms(entitylist)
        return

def WriteForms(entitylist):
        "Creates the 'Entity forms.qctx' folder for the input file and its entities."

    #    global bboxsize, dupebboxsize, bboxmin, bboxmax

        "This is the actual entity file writing format for QuArK"
        if entitylist == []: return
        switch_on = 0
        entityname = 0
        count = 0
        bboxmin = ""
        bboxmax = ""
        bboxsize = ""
        desccount = 0
        descdetailcount = 0

        for item in entitylist:

            if item.startswith('this can'): continue

            if item == ' ': continue

   #         print "NEW ITEM ",item

            if count == 100:
                bboxmin = item
                count = 0
                continue
            if count == 105:
                bboxmax = item
                count = 0
                continue
            if count == 110:
                bboxsize = item
                count = 0
                continue

            if item == "editor_mins":
                count = 100
                continue
            if item == "editor_maxs":
                count = 105
                continue
            if item == bboxname and bboxname != "":
                count = 110
                continue

            if item == description:
                desccount = 1
                continue

            if desccount == 1:
                item = string.replace(item,'.','')  # Removes all periods. (not good)
                item = string.replace(item,'*','')  # Removes all asterisk.  (may not be good)
                item = string.replace(item,'\\n','') # Removes all linefeeds.
                item = string.replace(item,'\\','')  # Removes all remaining backslashes.
                desccount = 0
                descdetailcount = 1
                continue

                     # This section Bypasses all detail description.
            if descdetailcount == 1:
                if item == ' \\' or item == '\\':
                    descdetailcount = 2
                    continue  # Bypasses double backslashes.

            if descdetailcount == 2:
                if item == ' \\' or item == '\\' or item == '\\n':
                    continue
                elif item == "spawnclass" or item == "inherit" or item == "start_open":
                    descdetailcount = 0
                else:
                    continue

            test = item
            splitline = string.split(test,'_') # splits up the "key" name to remove items.
            for word in splitline:
        #        if  word == "editor":
        #            splitname = 0
        #            count = 2
        #            break
                for remove in removespecifics:
                    if  word == remove:
                        splitname = 0
                        count = 2
                        break

            if count > 0:
                count = count - 1
                continue

            if item == ' ':
                continue
            if len(item) > 2:
                if item == ' //':
                    count = 1
                    continue
                if item[0] == '/' and item[1] == '/':
                    continue
                if item[0] == ' ' and item[1] == '/' and item[2] == '/':
                    continue

               # Below writes the bboxname item to create the bounding box,
               #    the addspecifics list entity form items
               #    and the right curly bracket of the entity that ends it all.
            if item == "}":
                entityname = 0

   ##             outfileFL.write("          bboxmin = "+bboxmin+"\n")
   ##             outfileFL.write("          bboxmax = "+bboxmax+"\n")
                if bboxsize != "":
            #    if bboxsize != "" and dupebboxsize == "1":
                #    x,y,z = string.split(bboxsize," ")
                #    test = (int(x)*-.5)
                #    print "test ",test,type(test),type(bboxsize)
                #    outfileFL.write("          bbox = \'")
                #    outfileFL.write(['bboxsize'])
                #    outfileFL.write("\'\n")

                    bboxsize = "-8 -8 -8 8 8 8" # put this temp. need integer or
                                                      # float to string function.
                    outfileFL.write("          bbox = \'"+bboxsize+"\'\n")
            #        dupebboxsize = dupebboxsize - 1
                else:
                    bboxsize = "-8 -8 -8 8 8 8"
                    outfileFL.write("          bbox = \'"+bboxsize+"\'\n")
           #         dupebboxsize = 1

                for add in addspecifics:
                    splitline = string.split(add,' ') # splits up the item to use just its name.
                    outfileFL.write("          "+splitline[0]+": = {Txt = \"&\"  Hint = \"\"}\n")
                outfileFL.write("        "+item+"\n")
                break

               # Below causes us to skip over the key word 'entityDef', not needed now.
            if item == entitylist[0]:
                continue
               # Below writes the entity name and adds the ':form =' to it.
            if item == entitylist[1] and entityname == 0:
                if item.endswith('{'):
                    item = string.replace(item,'{','')
                    outfileFL.write("        "+item+":form =\n")
                    outfileFL.write("        {\n")
                    switch_on = 1
                else:
                    outfileFL.write("        "+entitylist[1]+":form =\n")
                entityname = 1
                continue

               # Below writes the left curly bracket.
            if item == entitylist[2] and switch_on == 0:
                outfileFL.write("        "+entitylist[2]+"\n")
                switch_on = 1
                continue
               # Below switch_on causes it to write the name of the specific.
            if switch_on == 1:
                outfileFL.write("          "+item+": = ")
                switch_on = 0
                continue
               # Below switch_on causes it to write the basic label and hint for future additions.
            if switch_on == 0:
                outfileFL.write("{Txt = \"&\"  Hint = \"\"}\n") # This puts the value in double quotes.
                switch_on = 1                     #  and adds a line return.
                continue
        return

def WriteEntities():
        "Creates the 'Entities.qtxfolder' folder for the input file and its entities."
        filename = InputFileName(inputfile)
    #    print "      "+filename+" Entities.qtxfolder ="
    #    print "      {\n"
        if entitiessubfolder == "":
            outfileEL.write("      "+filename+" Entities.qtxfolder =\n")
            outfileEL.write("      {\n")
        else:
            outfileEL.write("        "+filename+" Entities.qtxfolder =\n")
            outfileEL.write("        {\n")

          # Starts reading in the inputfile data here.
        entitylist = []
        switch_on = 0
        gotleftcurly = 0
        gotspecific = 0
        skipline = 0
        while 1:
            line = inputdata.readline()

            if line == '': # completely empty line means end-of-file
                print "closing data input file"
                inputdata.close()
                break

    #        print "line input is  ",type(line)
    #        print line

            if line.startswith('	"editor_var'): continue

            if line.startswith('	//'): continue

            if line == "/*" or line == "*/": continue

            if line[0] == "/" and line[1] == "/": continue

            line = string.replace(line,'\"\"','None') # replaces 2 double quotes, for no setting to, "None"
            line = string.replace(line,'\"','\011') # removes all double quotes

            if switch_on == 0:
                splitline = string.split(line,' ') # splits the individual items
            if switch_on == 1:
                line = string.replace(line,'\" \"','\"    \"') # replaces single space between double quotes with 4 spaces
                line = string.replace(line,'  ',' ') # replaces 2 spaces with 1 space
                line = string.replace(line,'\'','') # removes single quote 
                splitline = string.split(line,'  ') # splits the individual items
            if splitline[0] == "//": continue

            for item in splitline:
                splitline = string.split(item,'\011') # splits the title
    #            print "splitline is"
    #            print splitline
                if splitline[0] == "entityDef":
                    switch_on = 1

                if len(splitline)>1:
                    newsplit = []
            #        if splitline[1] == '':
            #            blank = "None"
            #            newsplit.append(blank)
                    for item in splitline:
                        if item == '':
                            pass
                        else:
                            newsplit.append(item)
   #                 print "newsplit ",newsplit
                    for item in newsplit:
   #                     print "newsplit item ",item
                        finalsplit = string.split(item,'\012')
                        for item in finalsplit:
         #                   if item == "entityDef":
         #                       continue
         #                       switch_on = 1
                            if switch_on == 0: continue
   #                         print "finalsplit item ",item
                            if item == '':
   #                             print "got the CR"
                                pass
                            elif item == '}' or item == "} " or item == " }" or item == " } ":
                                item = string.replace(item,' ','')
                                entitylist.append(item)
                                gotleftcurly = 0
                                gotspecific = 0
   #                             print "completed entitylist item below"
   #                             print entitylist
   #                             for item in entitylist:
   #                                 print item
                                EntitiesLayout(entitylist)
                                entitylist = []
                                switch_on = 0
                                break
                            else:
                                entitylist.append(item)
                                if item == '{':
                                    gotleftcurly = 1
                                else:
                                    gotspecific = 1

                else:
                    for item in splitline:
   #                     print "newsplit item ",item
                        finalsplit = string.split(item,'\012')
                        for item in finalsplit:
                            if item == "entityDef":
                                switch_on = 1
                            if switch_on == 0: continue
   #                         print "finalsplit item ",item
                            if item == '':
   #                             print "got the CR"
                                pass
                            elif item == '}' or item == "} " or item == " }" or item == " } ":
                                item = string.replace(item,' ','')
                                entitylist.append(item)
                                gotleftcurly = 0
                                gotspecific = 0
   #                             print "completed entitylist item below"
   #                             print entitylist
   #                             for item in entitylist:
   #                                 print item
                                EntitiesLayout(entitylist)
                                entitylist = []
                                switch_on = 0
                                break
                            else:
                                entitylist.append(item)
                                if item == '{':
                                    gotleftcurly = 1
                                else:
                                    gotspecific = 1


  #          WriteForms()

          # Below to close out 'Entity forms.qctx' folder properly in FormsList.py file.
        outfileFL.write("  }\n")

          # Below to close out 'Entities.qtxfolder' folders properly in EntityList.py file.
        if entitiessubfolder == "":
            pass
        else:
            outfileEL.write("        }\n")
        outfileEL.write("      }\n")
        outfileEL.write("    }\n")
        outfileEL.write("  }\n")


#### Here down checks what files exist and calls the above functions to create the Entity Output files ###

if len(inputfile) != 0:
    try:
        inputdata = open(inputfile)  # Try�s to open the given input file.
        print "\nFOUND INPUT FILE:\n"+inputfile+"\nConverting items now."

        try:
            f = open("EntityList.py")  # Opens this file if it already exist and
                                       # copys it before adding new items.
            print "\nFOUND existing EntityList.py file.\nCoping its data now.\n"
            while 1:
                line = f.readline()
    #            print line
                if line == '    }\n': # Stops coping at this point to keep open for add items.
                    print "closing file"
                    f.close()
                    outfileEL = open("EntityList.py", "w")
                    outfileEL.write(text)
                    text = ""

                        # If there is a new sub-folder, this creates its folder.
                    if entitiessubfolder == "":
                        pass
                    else:
                        outfileEL.write("      "+entitiessubfolder+" Entities.qtxfolder =\n")
                        outfileEL.write("      {\n")

                    break
                text = text + line
   #         print text

        except (IOError):
            print "\nEntityList.py file NOT FOUND.\n"
            print "Creating EntityList.py file now.\n"
            print "Adding needed folders header now.\n"
               ## Section below crates the needed folders header
            outfileEL = open("EntityList.py", "w")
            outfileEL.write("  "+gameentities+"Entities.qtx =\n")
            outfileEL.write("  {\n")
            outfileEL.write("    ToolBox = \"New map items...\"\n")
            outfileEL.write("    Root = \""+gameentities+" Entities.qtxfolder\"\n")
            outfileEL.write("    "+gameentities+" Entities.qtxfolder =\n")
            outfileEL.write("    {\n")

            if entitiessubfolder == "":
                pass
            else:
                outfileEL.write("      "+entitiessubfolder+" Entities.qtxfolder =\n")
                outfileEL.write("      {\n")

        try:
            f = open("FormsList.py")   # Opens this file if it already exist and
                                       # copys it before adding new items.
            print "\nFOUND existing FormsList.py file.\nCoping its data now.\n"
            while 1:
                line = f.readline()
                if line == '  }\n': # Stops coping at this point to keep open for add items.
                    f.close()
                    outfileFL = open("FormsList.py", "w")
                    outfileFL.write(text)
                    text = ""
                    break
                text = text + line
   #         print text
               ## Below calls the function to write the new entities to the EntityList.py file which
               ## in turn calls the function to add the new entities to the FormsList.py file also.
            print "Adding convertion items now.\n"
            WriteEntities()

        except (IOError):
            print "\nFormsList.py file NOT FOUND.\n"
            print "Creating FormsList.py file now.\n"
            print "Adding needed folder header now.\n"
               ## Section below crates the needed folder header
            outfileFL = open("FormsList.py", "w")
            outfileFL.write("  Entity forms.qctx =\n")
            outfileFL.write("  {\n")
               ## Below calls the function to write the new entities to the EntityList.py file which
               ## in turn calls the function to add the new entities to the FormsList.py file also.
            print "Adding convertion items now.\n"
            WriteEntities()

    except (IOError):
        print "\nALERT:\n"
        print "The input file\n\n"+inputfile+"\n\ndoes not exist or the path is incorrect - nothing was converted"
        pass
else:
    print "You did not give an input file to convert."

# To close all the open files.
outfileEL.close()
print "All files closed"
outfileFL.close()

print "Conversion completed, files created and\or updated."
