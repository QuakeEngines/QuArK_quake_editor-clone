# KeyWordList.py - Makes a list of all entities, their Specifics and ;desc\Help\hint data
#                -   in each file by folder to use in creating the addon.qrk file.
#            - cdunde Oct. 12, 2006
#            - Put this file and the main work folder (with its sub-folder[s]) in the same directory.
#            - Change the "Path" and "File type" for the list below.
#            - Start the "DOS Command Window", cd (change directory) to the path location.
#            - Type in "python KeyWordList.py" and hit Enter.
#            - The completed file will be created in the same location as this file is.
#            - This program will go one sub-folder deep.
# cdunde, Oct. 14, 2006

import os, os.path, string

### Input variables that you must give or change.  ###

workdirectory = "c:\\cdunde_Q4\\"  ### Set Path here to your work folder.

dirname = workdirectory + "files_to_check"  ### Set the name of the folder to be scanned.

	# You can remove keywords to be considered by adding their
	#   name (which usually has a "_" after it) to this list.
	# For example: take the item editor_color, adding its name
	#   "editor_color" will cause it to be excluded from the final keyword list.
	# Each item MUST be in SINGLE quotes followed by a comma except
	#   for the last item which does not take a comma, as shown.
excludekeywords = [
'editor_color',
'editor_mins',
'editor_maxs',
'editor_targetonsel',
'editor_showangle',
'editor_ignore',
'editor_material',
'editor_copy',
'editor_copy100',
'editor_copy101',
'editor_menu',
'editor_mover',
'editor_rotatable',
'editor_ragdoll'
                  ]


### Start of program ###


temp = []  ### Global item used for storing keywords.

o = open("c:\\cdunde_Q4\\KeyWordListOutput.txt", "w")  ### Change output list name here if you want.

names = os.listdir(dirname)
names.sort()

def HandleInput(input):
        global temp
        KeyWord = ""
        count = 0
        while 1:
            line = input.readline()
            if line == '':
                break
            line = line.strip()   ### Removes leading and trailing white spaces only.
                 ### chr(32)=space, chr(9)=tab, chr(10)=newline
            if line.startswith('entityDef'):
       #         o.write('\n')    ### Un-comment to write entire entityDef lines that are found.
                update = 1
                line = line.replace(chr(9), ' ')  ### chr(9) is one 'tab'.
                line = line.replace('{','')
                if line.endswith(' \n'):
                    line = line.replace(' \n','\n')  ### good, leave in.
                line = line.strip()   ### Removes leading and trailing white spaces only.
                c = line.split(' ')
                entityKeyWord = c[0]
                entityName = c[1]
       #         o.write(entityKeyWord + " .... " + entityName + '\n')  ### Un-comment to write entire entityDef lines that are found.

            if line.startswith('\"editor_'):
                for keyword in excludekeywords:
                    if line.startswith('\"'+keyword):
                        break
                else:
                    if update == 1:
                        o.write("\n\n")
                        o.write(entityKeyWord + '\n')
                        o.write(entityName + '\n')
                        update = 0
      #              o.write(line + '\n')    ### Un-comment to write entire entityDef lines that are found.
                    line = line.replace(chr(9), ' ')  ### chr(9) is one 'tab'.
                    c = line.split(' ',2)
                    for word in c:
                        word = word.strip()   ### Removes leading and trailing white spaces only for each word.
                        if count < 2:
                            word = word.replace('"','')
                            if count == 0:
                                KeyWord = word
                            if count == 1:
                                SpecificName = word
                            count = count + 1
                        hint = word
                    o.write(KeyWord + '\n')
                    o.write(SpecificName + '\n')
                    o.write(hint + '\n\n')
                    count = 0

                    if temp == []:
                        temp.append(KeyWord)

                    tempsize = len(temp)
                    for item in temp:
                        tempsize = tempsize - 1
                        if KeyWord == item:
                            break
                        if tempsize == 0:
                            temp.append(KeyWord)

        input.close()
   #     o.write("\n\n")


### This section handles all the files in the main "files to check" folder, FIRST.

#o.write(dirname + "\n")   ### Un-comment to write the main directory name to our file to be scanned.
for name in names:
    if name.endswith(".def"):              ### Checks if this is a file name or a folder name.
  #      o.write("       " + name  + "\n")  ### Un-comment to write the file name in this folder first.
        input = open(os.path.join(dirname, name))  ### Opens our file to scanned for keywords.
        HandleInput(input)  ### Sends the text of our file to the function above for processing.
#o.write("\n\n")  ### Un-comment to write the file name in this folder first.


### This section handles all the files in the SUB-FOLDERS, starting with the 1st sub-folder.

for name in names:
    if name.endswith(".def"):   ### Checks if this is a file name or a folder name
        pass
    else:
        foldername = dirname + "\\" + name
  #      o.write(foldername + "\n")   ### Un-comment to write the sub-folder name to our file.
        filenames = os.listdir(foldername)
        filenames.sort()
        for name in filenames:
            if name.endswith(".def"):
  #              o.write("       %s" % name  + "\n")  ### Un-comment to write the file name in this folder first.
                input = open(os.path.join(foldername, name))
                HandleInput(input)
  #      o.write("\n\n")  ### Un-comment to write the file name in this folder first.


o.close()

o = open(workdirectory + "KeyWordList.txt", "w")

temp.sort()
for item in temp:
    o.write(item + '\n')
o.close()
