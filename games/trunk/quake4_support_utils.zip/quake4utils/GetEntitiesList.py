# GetEntitiesList.py - Makes a list of all entities, their Specifics and ;desc\Help\hint data
#                -   in each file by folder to use in creating the addon.qrk file.
#            - cdunde Oct. 12, 2006
#            - Put this file and the main work folder (with its sub-folder[s]) in the same directory.
#            - Change the "Path" and "File type" for the list below.
#            - Start the "DOS Command Window", cd (change directory) to the path location.
#            - Type in "python GetEntitiesList.py" and hit Enter.
#            - The completed file will be created in the same location as this file is.
#            - This program will go one sub-folder deep.
# cdunde, Oct. 12, 2006

import os, os.path, string

workdirectory = "c:\\cdunde_Q4\\"  ### Set Path here to your work folder.
dirname = workdirectory + "files_to_check"  ### Set the name of the folder to be scanned.


o = open("c:\\cdunde_Q4\\EntitiesListOutput.txt", "w")  ### Change output list name here if you want

names = os.listdir(dirname)
names.sort()

def HandleInput(input):
        count = 0
        while 1:
            line = input.readline()
            if line == '':
                break
            line = line.strip()   ### Removes leading and trailing white spaces only.
                 ### chr(32)=space, chr(9)=tab, chr(10)=newline
            if line.startswith('entityDef'):
                o.write('\n')
                line = line.replace(chr(9), ' ')  ### chr(9) is one 'tab'.
                line = line.replace('{','')
                if line.endswith(' \n'):
                    line = line.replace(' \n','\n')  ### good, leave in.
                line = line.strip()   ### Removes leading and trailing white spaces only.
                c = line.split(' ')
                entityKeyWord = c[0]
                entityName = c[1]
      #          o.write(line)
                o.write(entityKeyWord + " .... " + entityName)
                o.write('\n')
            if line.startswith('\"editor_var'):
                o.write(line)
                o.write('\n')
                line = line.replace(chr(9), ' ')  ### chr(9) is one 'tab'.
                c = line.split(' ',2)
                for word in c:
                    word = word.strip()   ### Removes leading and trailing white spaces only for each word.
                    if count < 2:
                        word = word.replace('"','')
                        if count == 0:
                            KeyWord = word
                        if count == 1:
                            SpecificName = word
                        count = count + 1
                    hint = word
             #       o.write(word)
             #       o.write('\n')
                o.write(KeyWord + '\n')
                o.write(SpecificName + '\n')
                o.write(hint + '\n\n')
                count = 0

        input.close()
        o.write("\n\n")


### This section handles all the files in the main "files to check" folder, FIRST.

o.write(dirname + "\n")         ### Writes the main directory name to our file.
for name in names:
    if name.endswith(".def"):              ### Checks if this is a file name or a folder name.
        o.write("       " + name  + "\n")  ### Lists all the files in this folder first.
        input = open(os.path.join(dirname, name))
        HandleInput(input)
o.write("\n\n")


### This section handles all the files in the SUB-FOLDERS, starting with the 1st sub-folder.

for name in names:
    if name.endswith(".def"):   ### Checks if this is a file name or a folder name
        pass
    else:
        foldername = dirname + "\\" + name
        o.write(foldername + "\n")   ### Writes the sub-folder name to our file.
        filenames = os.listdir(foldername)
        filenames.sort()
        for name in filenames:
            if name.endswith(".def"):
                o.write("       %s" % name  + "\n")  ### Lists all the files in this folder first.
                input = open(os.path.join(foldername, name))
                HandleInput(input)
        o.write("\n\n")


o.close()