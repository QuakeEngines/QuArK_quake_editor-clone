# NewUpdate.py - Updates the DataQ4.qrk file entities, their Specifics and ;desc\Help\hint data
#    using the KeyWordList.txt and KeyWordListOutput.txt files created from running KeyWordList.py.
#            - Put this file and DataQ4.qrk in the main work folder with the KeyWordList.py file
#            - then call it at the very end of the KeyWordList.py file or run it separately by
#            - Start the "DOS Command Window", cd (change directory) to the main work folder path location.
#            - Type in "python NewUpdate.py" and hit Enter.
#            - The updated_DataQ4.qrk file will be created in the same location as this file is.
#            - To get an output log type in "python NewUpdate.py > NewUpdate.log" and hit Enter.
# cdunde, Oct. 15, 2006

import os, os.path, string

### Input variables that you must give or change.  ###

workdirectory = "c:\\cdunde_Q4\\"  ### Set Path here to your work folder.


### Start of program ###

i = open(workdirectory + "KeyWordListOutput.txt")
entities = []
start = 0

while 1:
    s = i.readline()
    if s == "":
        break
    s = s.strip()
    if s.startswith("entityDef"):
        if start == 0:
            firstentity = s
            start = 1
        while 1:
            if s == "":
                break
            if s.startswith("entityDef"):
      #          entityName = i.readline()
      #          entityName = entityName.strip()
                entityName = []
                while 1:
                    s = i.readline()
                    if s == "":
                        break
                    if s.startswith('\"'):
                        s = s.replace('\\n', '')
                        s = s.replace('\\', '')
            #        s = s.replace('\"', '')
                    s = s.strip()
                    if s.startswith("entityDef"):
                        break
                    else:
                        if s == "" or s == "\"\"": continue
                        entityName.append(s)  ### This makes a list of each entity and all its other items.
           #     print entityName  ### will print to a log the list of each entity from our update input.
                entities.append(entityName)  ### This makes a list of all of the above lists.

i.close()


Org_qrk_file = open(workdirectory + "DataQ4.qrk")
Updated_qrk_file = open(workdirectory + "updated_DataQ4.qrk", "w")

temp_Org_qrk = []
temp_entity_update = []  ### Use this storage of the entity for updating and all future update functions.
foundstart = 0

   ### First we need to find the 1st entity to be updated in the DataQ4.qrk file.
while 1:
    copyline = Org_qrk_file.readline()
    if copyline == '' or foundstart == 1:
        break
    stripedcopyline = copyline.strip()
    if stripedcopyline.find(str(entities[0][0])+":form =") != -1: # Got the same first entity in our DataQ4.qrk file.
        foundstart = 1
        break
    else:
        Updated_qrk_file.write(copyline)

#1print len(entities)  ### prints how many entities we have with update input.

while 1:
    if foundstart == 1:
        foundstart = 0
        pass
    else:
        copyline = Org_qrk_file.readline()
        stripedcopyline = copyline.strip()
        if copyline == '':
            break
    for entity in entities:
        if stripedcopyline.find(str(entity[0])+":form =") != -1: # Got the same first entity in our DataQ4.qrk file.
            temp_entity_update.append(copyline)  ### This is only the 1st .qrk entity which matches our 1st update entity.
            entityname =  stripedcopyline.replace(":form =", "")
            temp_Org_qrk.append(entityname)
        else:
            temp_entity_update.append(copyline)  ### This is all the other .qrk entities, some may NOT have any updating.
            entityname =  stripedcopyline.replace(":form =", "")
            temp_Org_qrk.append(entityname)

        while 1:
            copyline = Org_qrk_file.readline()
            if copyline == '':
                break
            if copyline.startswith("    }"):
                temp_Org_qrk.append(copyline)
                break
            else:
                temp_Org_qrk.append(copyline)


   ### Tries to match qrk stored list entity name with entity name in update entities list.
        temp_entity = []
        entcount = -1
        for entity in entities:
            entcount = entcount + 1
            if entcount >= len(entities):
                temp_entity = []
                break
            if temp_Org_qrk[0] == entities[entcount][0]:
                temp_entity = entities[entcount]
                break
        if temp_entity == []:
            pass

        else:
   #         print entcount  ### prints each update entitys number.

              ### Now we make our Help section starting with any general information.
            HelpText = "      help = "
            begincount = 0
            itemcount = -1
            for item in temp_entity:
                itemcount = itemcount + 1
                if itemcount + 1 >= len(temp_entity):
                    break
                if item.startswith("editor_usage"):
                    if temp_entity[itemcount + 1] == "" and temp_entity[itemcount + 2].startswith("\""):
                        itemcount = itemcount + 1
                    if temp_entity[itemcount + 1].startswith("entityDef") or temp_entity[itemcount + 1].startswith("editor_"):
                        break
                    if begincount == 0:
                        HelpText = HelpText + temp_entity[itemcount + 1] + "$0D\n"
                        begincount = 1
                    else:
                        HelpText = HelpText + "             " + temp_entity[itemcount + 1] + "$0D\n"
              ### Now we add on the Help section for this entity.
            itemcount = -1
            thisentityspecifics = []  ### This is a list we will build below of all the entities in the "Help" section for comparison latter.
            for item in temp_entity:
                itemcount = itemcount + 1
                if itemcount + 1 >= len(temp_entity):
                    break
                if item.startswith("editor_bool") or item.startswith("editor_float") or item.startswith("editor_gui") or item.startswith("editor_mat") or item.startswith("editor_var") or item.startswith("editor_model") or item.startswith("editor_snd"):
                    HelpText = HelpText + "          $0D\"     \"$22\"" + temp_entity[itemcount + 1] + "\"$220D\n"
                    thisentityspecifics.append(temp_entity[itemcount])
                    thisentityspecifics.append(temp_entity[itemcount + 1])
                    if itemcount + 2 >= len(temp_entity):
                        break
                    if temp_entity[itemcount + 2] == "":
                        thisentityspecifics.append("None")
                        break
                    HelpText = HelpText + "             " + temp_entity[itemcount + 2] + "$0D\n"
                    thisentityspecifics.append(temp_entity[itemcount + 2])


    #        print temp_entity   ### Prints what update data is in this entitys list of items.
    #        print HelpText      ### Prints what is in the Help section that will be added.
            print thisentityspecifics   ### Prints this entity's Specifics listing for comparison and addition.

        if len(HelpText) <= 13:  ### If there is nothing for Help we leave it out.
            HelpText = ""

          ### Here we check for any existing Help in the qrk file. If so leave it. If no Help then add ours.
        hashelp = 0
        hastarget = 0
        hastargetname = 0
        for item in temp_Org_qrk:
            if item.startswith("      Help =") or item.startswith("      help ="):
                hashelp = 1
            if item.startswith("      target:"):
                hastarget = 1
            if item.startswith("      targetname:"):
                hastargetname = 1
                break
        if hashelp == 1:
            for item in temp_Org_qrk:
                if item == temp_Org_qrk[0]:
                    pass
                else:
                    temp_entity_update.append(item)


        else:
            for item in temp_Org_qrk:
                if item == temp_Org_qrk[0]:
                    pass
                else:
                    if item.startswith("    {"):
                        temp_entity_update.append(item)
                        temp_entity_update.append(HelpText)
                        HelpText = ""
                    else:
                        temp_entity_update.append(item)

            ### This part adds the "target" and "targetname" Specifics if none exist already.
        temp_hold = []
    #    print temp_entity_update  ### Prints what is stored .


        qrk1stspec = 0 ### To setup a switch.
        specsadded = 0 ### To setup a switch.


        for item in temp_entity_update:
            if item.startswith("    }"):
                temp_hold.append(item)

                qrk1stspec = 0 ### To reset this switch.
                specsadded = 0 ### To reset this switch.

                break

               ### To allow for "include" items.
            if item.endswith("= !\n") or item.endswith("]\"\n"):
                temp_hold.append(item)
                continue

            spawnclass = 0
            if item.startswith("      spawnclass:"):   ### To start adding after these type of Specifics.
                spawnclass = 1
            if item.endswith(": =\n") and spawnclass == 0:
                if hastarget == 0:
                    target = "      target: =\n      {\n        Txt = \"&\"\n        Hint = \"Name of the entity that this one targets.\"\n      }\n"
                    hastarget = 1
                    temp_hold.append(target)
                if hastargetname == 0:
                    targetname = "      targetname: =\n      {\n        Txt = \"&\"\n        Hint = \"Name of this entity, used as a target by another entity.\"\n      }\n"
                    hastargetname = 1
                    temp_hold.append(targetname)


      #          temp_hold.append(item)  ### KEYPOINT This is the next Specific to be added after all the spawnclasses, target and targetname.

                  ### Now we sort through all the "Help" Specifics adding those that are missing and hints for those that already exist.

                if qrk1stspec == 0:
                    qrk1stspec = 1
                    specificscount = -1
                    if thisentityspecifics == []:
                        specsadded = 0
                        temp_hold.append(item)
                        continue
                    for specitem in thisentityspecifics:
                        specificscount = specificscount + 1
                        if specificscount + 1 >= len(thisentityspecifics):
                           break
                        if specitem.startswith("editor_"):
                            specific = "      " + thisentityspecifics[specificscount + 1] + ": =\n      {\n        Txt = \"&\"\n"
                            if specificscount + 2 >= len(thisentityspecifics):
                                break
                            specific = specific + "        Hint = " + thisentityspecifics[specificscount + 2] + "\n      }\n"
                            temp_hold.append(specific)

              #  if item.find("      " + str(thisentityspecifics)+": =\n") != -1:
              #      specificscount = -1
              #      for specitem in thisentityspecifics:
              #          itemcount = itemcount + 1

              #  else:

        #A        if specsadded == 1: continue ### this is just temp for testing

                if thisentityspecifics == []:
                    specsadded = 0
                    temp_hold.append(item)
                    continue
                specificscount = -1
                for specitem in thisentityspecifics:
                    specificscount = specificscount + 1
               #     if specificscount >= len(thisentityspecifics):
               #         specsadded = 0
               #         temp_hold.append(item)
               #         break
                    if specificscount + 1 >= len(thisentityspecifics):
                        specsadded = 0
                        temp_hold.append(item)
                        break
                    if specitem.startswith("editor_"):
                        specific = "      " + thisentityspecifics[specificscount + 1] + ": =\n      {\n        Txt = \"&\"\n"
                        if specific.startswith(item):
                            specsadded = 1
                            break    #B
                   #B         if specificscount + 2 >= len(thisentityspecifics):
                   #B             specific = specific + "        Hint = \"\"\n      }\n"
                   #B             temp_hold.append(specific)
                   #B             break
                   #B         else:
                   #B             specific = specific + "        Hint = " + thisentityspecifics[specificscount + 2] + "\n      }\n"
                   #B             temp_hold.append(specific)
                   #B             break
              #          else:
              #              specsadded = 0
              #              temp_hold.append(item)
                    else:
         #A               temp_hold.append(item)
                        pass

         #A       specsadded = 1 ### this is just temp for testing


               ### This adds the body of each Specific.
            else:

                if specsadded == 1: continue ### this is a switch, used to write (0) or not write (1) the body of a qrk file entity.

                if item.startswith("      spawnclass:"):
                    spawnclass = 0
                temp_hold.append(item)


        temp_entity_update = temp_hold
   #     print temp_entity_update  ### Prints what is NOW stored after "target" and "targetname" are added .


            ### This part sorts through the entity's "Specific" items and merges their new ones.
        temp_hold = []




            ### Now we write the final updated entity to our new .qrk file.
        for item in temp_entity_update:
            Updated_qrk_file.write(item)

     #   print temp_Org_qrk  ### Prints what is stored from the Original .qrk entity.
        temp_Org_qrk = []
        temp_entity = []
        temp_entity_update = []
        thisentityspecifics = []

        break

    else:
        Updated_qrk_file.write(copyline)

Org_qrk_file.close()
Updated_qrk_file.close()















