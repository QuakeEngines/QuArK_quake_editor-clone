# ent1.py - convert Doom 3 entity files to QuArK format (hopefully)

import os

NUMBERS = '0123456789-.'
ALPHAS  = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_'

T_EOF        = 1
T_NUMBER     = 2
T_COMMENT    = 3
T_COMMENT    = 4
T_QSTRING    = 5
T_IDENTIFIER = 6
T_SPECIAL    = 7

srcLine = ''
srcPos = 0

def unGetChar(ch):
    global srcLine, srcPos
    if srcPos > 0:
        srcPos -= 1
    else:
        srcLine = ch + srcLine

def getChar(infile):
    global srcLine, srcPos
    if srcPos >= len(srcLine):
        srcLine = infile.readline()
        if srcLine == "":
            return chr(4) # eof
        srcPos = 0
    result = srcLine[srcPos]
    if result == '\r':
        result = '\n'
    srcPos += 1
    return result

def getToken(infile):
    result = ''
    ch = getChar(infile)
    while ch.isspace():
        ch = getChar(infile)
    if ch == chr(4):
        return T_EOF, None
    # is it a number, ident, quoted string or special?
    if ch in '0123456789-.':
        result = ch
        ch = getChar(infile)
        while ch in '0123456789.':
            result += ch
            ch = getChar(infile)
        unGetChar(ch)
        return T_NUMBER, result
    if ch == '/':
        # comment???
        ch = getChar(infile)
        if ch == '/':
            # single line comment - read until eoln
            result = '/'
            while (ch != chr(4)) and (ch != '\n'):
                result += ch
                ch = getChar(infile)
            # we don't need to do this: unGetChar(ch)
            return T_COMMENT, result
        if ch == '*':
            # multiline comment - read until end of multiline comment
            result = '/'
            lastCh = '/'
            while (ch != chr(4)) and ((ch != '/') or (lastCh != '*')):
                lastCh = ch
                result += ch
                ch = getChar(infile)
            result += ch
            # we don't want to do this here: unGetChar(ch)
            return T_COMMENT, result
        # not a comment, push the last char back and let's keep comparing
        unGetChar(ch)
    if ch == '"':
        # quoted string - read until the next quote
        result = '"'
        ch = getChar(infile)
        while (ch != chr(4)) and (ch != '"'):
            result += ch
            ch = getChar(infile)
        result += ch
        # we don't want to do this here: unGetChar(ch)
        return T_QSTRING, result
    if ch.isalpha() or (ch == '_'):
        # identifier (probably, or something fairly close to it)
        # might also be a (UNIX) pathname
        result = ch
        ch = getChar(infile)
        while (ch != chr(4)) and (ch.isalnum() or (ch in '_/.')):
            result += ch
            ch = getChar(infile)
        unGetChar(ch)
        return T_IDENTIFIER, result
    # dunno what we've got, treat it as special
    return T_SPECIAL, ch

def getTokens(inname):
    infile = open(inname)
    result = []
    while 1:
        tokenType, tokenValue = getToken(infile)
        result.append((tokenType, tokenValue))
        if tokenType == T_EOF:
            break
    infile.close()
    return result

o = open('ent1.txt', 'w')
o.write('  D3Entities.qtx =\n')
o.write('  {\n')
o.write('    ToolBox = "New map items..."\n')
o.write('    Root = "Doom3 Entities.qtxfolder"\n')
o.write('    Doom3 Entities.qtxfolder =\n')
o.write('    {\n')

dirname = 'c:\\cdunde_tooltest\\workfolder'
names = os.listdir(dirname)
names.sort()
for name in names:
    if name.endswith('.def'):
        print "processing: %s" % name

        o.write('      %s.qtxfolder =\n' % name)
        o.write('      {\n')

        i = open(dirname + '\\' + name)
        insideComment = 0 # useful for multi-line comments /* ... */
        skipSection = 0 # useful for skipping irrelevant brace-delimited blocks
        while 1:
            s = i.readline()
            if s == '':
                break
            s = s.replace('\n', '').replace('\r', '').strip()
            if s.startswith('/*'):
                insideComment = 1
            if (insideComment == 1) and s.endswith('*/'):
                insideComment = 0
                continue
            if insideComment or s.startswith('//'):
                continue
            if (skipSection == 1) and (s == '}'):
                skipSection = 0
                continue
            if s.startswith('entityDef'):
                if (s.find('_types {') != -1) or (s.find('_names {') != -1):
                    print '    %s - skipping' % s
                    skipSection = 1
                    continue
                s = s.replace('\t', ' ').strip()
                c = s.split(' ')
                entName = c[1]
                print "    %s" % entName
                o.write('        %s:e =\n' % entName)
                o.write('        {\n')
                # copy all the entity args
                foundOrigin = 0
                foundName = 0 # seems all Doom 3 entities need a name
                insideInsideComment = 0
                while 1:
                    s = i.readline()
                    if s == '':
                        break
                    s = s.replace('\n', '').replace('\r', '').strip()
                    if s == '':
                        continue

                    if s.startswith('/*'):
                        insideInsideComment = 1
                    if (insideInsideComment == 1) and s.endswith('*/'):
                        insideInsideComment = 0
                        continue
                    if insideInsideComment or s.startswith('//'):
                        continue

                    if s.startswith('"editor_'):
                        continue

                    if s == '}':
                        break
                    s = s.replace('\t', ' ')
                    s = ' '.join(s.split())

                    # in monster_default.def where are some lines that start with a quoted string
                    if s.find('" "') == -1:
                        continue

                    s = s.replace('" "', '~')
                    s = s.replace('"', '')
                    c = s.split('~')
                    #print "before: %s" % s
                    #print "after:  %s" % str(c)
                    argName = c[0]
                    argValue = c[1]

                    q = argValue.find('//')
                    if q != -1:
                        argValue = argValue[:q]
                    argValue = argValue.strip()

                    o.write('          %s = "%s"\n' % (argName, argValue))
                    if (argName == 'origin') or (argName == '"origin"'):
                        foundOrigin = 1
                    if (argName == 'name') or (argName == '"name"'):
                        foundName = 1
                if foundOrigin == 0:
                    o.write('          origin = "0 0 0"\n')
                if foundName == 0:
                    o.write('          name = "[auto]"\n')
                o.write('        }\n')

        i.close()

        o.write('      }\n')

o.write('    }\n')
o.write('  }\n')

o.close()

tokens = getTokens("c:\\cdunde_tooltest\\workfolder\\aas.def")
for tokenType, tokenValue in tokens:
    if tokenType == T_EOF:
        print "end of file"
    elif tokenType == T_NUMBER:
        print "number: %s" % tokenValue
    elif tokenType == T_COMMENT:
        print "comment: %s" % tokenValue
    elif tokenType == T_QSTRING:
        print "quoted string: %s" % tokenValue
    elif tokenType == T_IDENTIFIER:
        print "identifier: %s" % tokenValue
    elif tokenType == T_SPECIAL:
        print "special: %s" % tokenValue
    else:
        print "internal error: unrecognised token type: %d" % tokenType
        break


dirname = 'c:\\cdunde_tooltest\\workfolder'
names = os.listdir(dirname)
names.sort()
for name in names:
    if name == 'aas.def': #name.endswith('.def'):
        print "processing: %s" % name
        tokens = getTokens(dirname + '\\' + name)
   #     print "tokens are"
   #     print tokens
        for tokenType, tokenValue in tokens:
            if tokenType == T_NUMBER:
                print "    found number: %s" % tokenValue

"""
specifics to skip:
	"editor_color"				"0 .5 .8"
	"editor_mins"				"?"
	"editor_maxs"				"?"
	"editor_mover"				"1"
	"editor_usage"				"Door."
	"spawnclass"				"idDoor"


allEntities = {'func_door':
                           {'start_open':         ('b', '0',                     "the door moves to its destination when spawned, and operate in reverse.  It is used to temporarily or permanently close off an area when triggered (not useful for touch or takedamage doors)."),
                            'no_touch':           ('b', '0',                     "the door should not be triggered by the player touching it, only by another trigger. in multiplayer, this door can't be shot to open."),
                            'locked':             ('b', '',                      "used in conjunction with no_touch,the door must be triggered by a trigger, after which it works normally.  if locked = 1 then the door opens when unlocked, if locked = 2 then the door just becomes unlocked."),
                            'buddy':              ('v', '',                      "will toggle shaderparm 7 of the entity given as a buddy, this allows shaders to be remapped for lock status etc."),
                            'crusher':            ('b', '0',                     "the door does not reverse when blocked."),
                            'angle':              ('v', '0',                     "determines the opening direction."),
                            'movedir':            ('v', '',                      "determines the opening direction.  if set, 'angle' determines orientation."),
                            'speed':              ('v', '100',                   "movement speed."),
                            'time':               ('v', '',                      "movement time in seconds.  overrides speed.  used for doors that move different distances, but still need to be synced."),
                            'wait':               ('b', '3',                     "wait before returning (-1 = never return)."),
                            'toggle':             ('b', '',                      "wait at each position until triggered again."),
                            'lip':                ('v', '8',                     "lip remaining at end of move."),
                            'dmg':                ('v', '2',                     "damage to inflict when blocked."),
                            'health':             ('v', '0',                     "if set, the door must be shot open."),
                            'triggersize':        ('v', '60',                    "sets the amount the trigger extends from the door."),
                            'gui_noninteractive': ('b', '',                      "any gui attached will not be interactive"),
                            'snd_locked':         ('s', "default_door_locked",   "sound to play if door is locked and player approaches."),
                            'snd_open':           ('s', "default_door_open",     "sound to play when opening."),
                            'snd_close':          ('s', "default_door_close",    "sound to play when closing."),
                            'snd_opened':         ('s', "",                      "looping sound for it's opened state."),
                            'triggerClosed':      ('v', '',                      "name of entity to trigger when door closes, can be iterated with triggerClosed2, 3 etc."),
                            'triggerOpened':      ('v', '',                      "name of entity to trigger when door opens, can be iterated with triggerOpened2, 3 etc."),
                            'triggerBlocked':     ('v', '',                      "name of entity to trigger when door is blocked, can be iterated with triggerBlocked2, 3 etc."),
                            'snd_unlocked':       ('?', "default_door_unlocked", '')}}

this was auto-created after the first successful run of parseIntoDict():

              {'func_door':
                           {'start_open':         ('b', '0',                     '"the door moves to its destination when spawned, and operate in reverse.  It is used to temporarily or permanently close off an area when triggered (not useful for touch or takedamage doors)."'),
                            'no_touch':           ('b', '0',                     '"the door should not be triggered by the player touching it, only by another trigger. in multiplayer, this door can\'t be shot to open."'),
                            'locked':             ('b', '',                      '"used in conjunction with no_touch,the door must be triggered by a trigger, after which it works normally.  if locked = 1 then the door opens when unlocked, if locked = 2 then the door just becomes unlocked."'),
                            'buddy':              ('v', '',                      '"will toggle shaderparm 7 of the entity given as a buddy, this allows shaders to be remapped for lock status etc."'),
                            'crusher':            ('b', '0',                     '"the door does not reverse when blocked."'),
                            'angle':              ('v', '0',                     '"determines the opening direction."'),
                            'movedir':            ('v', '',                      '"determines the opening direction.  if set, \'angle\' determines orientation."'),
                            'speed':              ('v', '100',                   '"movement speed."'),
                            'time':               ('v', '',                      '"movement time in seconds.  overrides speed.  used for doors that move different distances, but still need to be synced."'),
                            'wait':               ('b', '3',                     '"wait before returning (-1 = never return)."'),
                            'toggle':             ('b', '',                      '"wait at each position until triggered again."'),
                            'lip':                ('v', '8',                     '"lip remaining at end of move."'),
                            'dmg':                ('v', '2',                     '"damage to inflict when blocked."'),
                            'health':             ('v', '0',                     '"if set, the door must be shot open."'),
                            'triggersize':        ('v', '60',                    '"sets the amount the trigger extends from the door."'),
                            'gui_noninteractive': ('b', '',                      '"any gui attached will not be interactive"'),
                            'snd_locked':         ('s', 'default_door_locked',   '"sound to play if door is locked and player approaches."'),
                            'snd_open':           ('s', 'default_door_open',     '"sound to play when opening."'),
                            'snd_close':          ('s', 'default_door_close',    '"sound to play when closing."'),
                            'snd_opened':         ('s', '',                      '"looping sound for it\'s opened state."'),
                            'triggerClosed':      ('v', '',                      '"name of entity to trigger when door closes, can be iterated with triggerClosed2, 3 etc."'),
                            'triggerOpened':      ('v', '',                      '"name of entity to trigger when door opens, can be iterated with triggerOpened2, 3 etc."'),
                            'triggerBlocked':     ('v', '',                      '"name of entity to trigger when door is blocked, can be iterated with triggerBlocked2, 3 etc."'),
                            'snd_unlocked':       ('?', 'default_door_unlocked', '')}}

differences?  well the specifics were in a different order (manually rearranged to assist checking), but that is irrelevant.
a few double-quotes in the manual one are single quotes in the progamatically created one (copy/paste vs. Python), otherwise they appear pretty much identical :-)


      Func Entities.qtxfolder =
      {
        func_button:b =
        {
          angle = "360"
          ;incl = "defpoly"
          ;desc = "Just a button."
        }
        func_door:b =
        {
          angle = "360"
          ;incl = "defpoly"
          ;desc = "A standard door"
        }
        func_plat:b =
        {
          angle = "360"
          ;incl = "defpoly"
          ;desc = "Used to lift the player in the air with a brush. Bots don't use well!"
        }
        func_timer:e =
        {
          origin = "0 0 0"
          ;desc = "A time delay trigger."
        }
      }

  Entity forms.qctx =
  {
    // Definition of "includes"
    t_player_size:incl = { bbox = '-16 -16 -24 16 16 32' }
    t_ammo_size:incl = { bbox = '-16 -16 -16 16 16 16' }
    t_weapon_size:incl = { bbox = '-16 -16 -16 16 16 16' }
    t_teleport_size:incl = { bbox = '-32 -32 -4 32 32 4' }
    t_item_size:incl = { bbox = '-16 -16 -16 16 16 16' }

    t_modelbrowser:incl = {
            Typ = "EP"
            DefExt = "md3"
            BasePath = "$Game\baseq3"
            CutPath = "$Game\?\models"
            DirSep = "/"
            AugPath = "models"
      }

    t_model:incl = {
      model: = { Txt = " "
        Typ = "B"
        Cap = "models..."
        form ="t_models_form:form"
        hint ="Available .MD3 files"
      }
    }
    t_model2:incl = {
      model2: = { Txt = " "
        Typ = "B"
        Cap = "models..."
        form ="t_models2_form:form"
        hint ="Available .MD3 files"
      }
    }
    t_noise:incl =
    {
      noise: =
      {
        Txt = " "
        Typ = "B"
        Cap = "sounds..."
        form = "t_noise_form:form"
        hint = "Available .WAV files"
      }
    }
    func_button:form =
    {
      mdl = "[model2]"
      Help = "This is something the player can push to trigger something."
      angle: =
      {
        Txt = "&"
        Hint = "Direction this brush moves.(up is -1, down is -2)"
      }
      target: =
      {
        Txt = "&"
        Hint = "Entities with same targetname will trigger with this."
      }
      speed: =
      {
        Txt = "&"
        Hint = "Speed at which button moves.(Default is 40)"
      }
      wait: =
      {
        Txt = "&"
        Hint = "Wait time till it resets.(Default is 1, -1 returns it immediately)"
      }
      lip: =
      {
        Txt = "&"
        Hint = "Remaining edge left.(Default is 4 units)"
      }
      health: =
      {
        Txt = "&"
        Hint = "If this is set it will need to be damaged to work.(This is the amount of damaged needed)"
      }
      notfree: =
      {
        Txt = "&"
        Hint = "This item will not work in a Free for All or Tournament game.(Default value is 0)"
      }
      notteam: =
      {
        Txt = "&"
	Hint = "This item will not work in a Teamplay or CTF game.(Default value is 0)"
      }
      model2: =
      {
        t_modelbrowser = !
        Txt = "&"
	Hint = "Path and name of a model."
      }
      t_model2 = !
      origin: =
      {
        Txt = "&"
	Hint = "Way to set the XYZ origin.(Default is the center of the brush)"
      }
	light: =
      {
        Txt = "&"
	Hint = "constantLight radius of .md3 model included with entity. Has no effect on the entity's brushes (default 0)."
      }
	color: =
      {
        Txt = "&"
	Hint = "constantLight color of .md3 model included with entity. Has no effect on the entity's brushes (default 1 1 1)."
      }
	notsingle: =
      {
        Txt = "&"
	Hint = "If set to 1, will not spawn in single player (bot play) mode."
      }
	notbot: =
      {
        Txt = "&"
	Hint = "If set to 1, bots will ignore this."
      }
    }
    func_door:form =
    {
      mdl = "[model2]"
      Help = "This is a door."
      angle: =
      {
        Txt = "&"
	Hint = "Direction this brush moves.(-1 is up, -2 is down)"
      }
      targetname: =
      {
        Txt = "&"
        Hint = "This is its target name for the target argument."
      }
      speed: =
      {
        Txt = "&"
	Hint = "Speed at which door moves.(Default is 100)"
      }
      wait: =
      {
        Txt = "&"
	Hint = "Wait time till it resets.(Default is 3, -1 returns immediately)"
      }

      lip: =
      {
        Txt = "&"
	Hint = "Remaining edge left.(Default is 8)"
      }
      health: =
      {
        Txt = "&"
        Hint = "If this is set it will need to be damaged to work."
      }
      dmg: =
      {
        Txt = "&"
	Hint = "Damage it will inflict when it closes on a player.(Default is 4)"
      }
      team: =
      {
        Txt = "&"
	Hint = "Assign the same team name to multiple doors that should operate together."
      }
      model2: =
      {
        t_modelbrowser = !
        Txt = "&"
        Hint = "Path and name of a model to use for door."
      }
      t_model2 = !
      origin: =
      {
        Txt = "&"
        Hint = "Way to set the XYZ value of this entity."
      }
      notfree: =
      {
        Txt = "&"
        Hint = "This item will not work in a Free for All or Tournament game.(Default value is 0)"
      }
      notteam: =
      {
        Txt = "&"
        Hint = "This item will not work in a Teamplay or CTF game.(Default value is 0)"
      }
	light: =
      {
        Txt = "&"
	Hint = "constantLight radius of .md3 model included with entity. Has no effect on the entity's brushes (default 0)."
      }
	color: =
      {
        Txt = "&"
	Hint = "constantLight color of .md3 model included with entity. Has no effect on the entity's brushes (default 1 1 1)."
      }
	notsingle: =
      {
        Txt = "&"
	Hint = "If set to 1, will not spawn in single player (bot play) mode."
      }
	notbot: =
      {
        Txt = "&"
	Hint = "If set to 1, bots will ignore this."
      }
      spawnflags: =
      {
        Txt = "&"
	Typ = "X1"
	Cap = "START_OPEN"
	Hint = "This door will start open."
      }
      spawnflags: =
      {
        Txt = "&"
	Typ = "X4"
	Cap = "CRUSHER"
	Hint = "This will crush the player."
      }
    }
    func_plat:form =
    {
      mdl = "[model2]"
      Help = "This a moving brush that lifts the player up or down."
      speed: =
      {
        Txt = "&"
        Hint = "This is the speed at which it swings."
      }
	origin: =
      {
	Txt = "&"
	Hint = "Way of setting XYZ coordinates."
      }
      lip: =
      {
        Txt = "&"
        Hint = "Remaining edge left."
      }
      height: =
      {
        Txt = "&"
        Hint = "When set this is the height the platform will rise."
      }
      dmg: =
      {
        Txt = "&"
        Hint = "Damage this causes to the player."
      }
      targetname: =
      {
        Txt = "&"
        Hint = "This is its target name for the target argument."
      }
      notfree: =
      {
        Txt = "&"
        Hint = "This item will not work in a Free for All or Tournament game.(Default value is 0)"
      }
      notteam: =
      {
        Txt = "&"
        Hint = "This item will not work in a Teamplay or CTF game.(Default value is 0)"
      }
	model2: =
      {
        t_modelbrowser = !
	Txt = "&"
	Hint = "Path and name of a model to use."
      }
      t_model2 = !
	light: =
	{
	Txt = "&"
	Hint = "constantLight radius of .md3 model included with entity. Has no effect on the entity's brushes (default 0)."
	}
	color: =
	{
	Txt = "&"
	Hint = "constantLight color of .md3 model included with entity. Has no effect on the entity's brushes (default 1 1 1)."
	}
	notsingle: =
	{
	Txt = "&"
	Hint = "If set to 1, will not spawn in single player (bot play) mode."
	}
	notbot: =
	{
	Txt = "&"
	Hint = "If set to 1, bots will ignore this."
	}
    }
    func_timer:form =
    {
      Help = "This is a time delay trigger."
      wait: =
      {
        Txt = "&"
        Hint = "Wait time till it resets."
      }
      random: =
      {
        Txt = "&"
        Hint = "The integer used to multiply or divide the wait value to the respawn."
      }
      target: =
      {
        Txt = "&"
        Hint = "Entities with same targetname will trigger with this."
      }
      targetname: =
      {
        Txt = "&"
        Hint = "This is its target name for the target argument."
      }
      notfree: =
      {
        Txt = "&"
        Hint = "This item will not work in a Free for All or Tournament game.(Default value is 0)"
      }
      notteam: =
      {
        Txt = "&"
        Hint = "This item will not work in a Teamplay or CTF game.(Default value is 0)"
      }
	notsingle: =
	{
	Txt = "&"
	Hint = "If set to 1, will not spawn in single player (bot play) mode."
	}
      spawnflags: =
      {
        Txt = "&"
        Typ = "X1"
        Cap = "START_ON"
        Hint = "This timer will start at game map load."
      }
    }
  }

        func_door:b =
        {
          angle = "360"
          ;incl = "defpoly"
          ;desc = "A standard door"
        }

    func_door:form =
    {
      mdl = "[model2]"
      Help = "This is a door."
      angle: =
      {
        Txt = "&"
	Hint = "Direction this brush moves.(-1 is up, -2 is down)"
      }
      targetname: =
      {
        Txt = "&"
        Hint = "This is its target name for the target argument."
      }
      speed: =
      {
        Txt = "&"
	Hint = "Speed at which door moves.(Default is 100)"
      }
      wait: =
      {
        Txt = "&"
	Hint = "Wait time till it resets.(Default is 3, -1 returns immediately)"
      }
      lip: =
      {
        Txt = "&"
	Hint = "Remaining edge left.(Default is 8)"
      }
      health: =
      {
        Txt = "&"
        Hint = "If this is set it will need to be damaged to work."
      }
      dmg: =
      {
        Txt = "&"
	Hint = "Damage it will inflict when it closes on a player.(Default is 4)"
      }
      team: =
      {
        Txt = "&"
	Hint = "Assign the same team name to multiple doors that should operate together."
      }
      model2: =
      {
        t_modelbrowser = !
        Txt = "&"
        Hint = "Path and name of a model to use for door."
      }
      t_model2 = !
      origin: =
      {
        Txt = "&"
        Hint = "Way to set the XYZ value of this entity."
      }
      notfree: =
      {
        Txt = "&"
        Hint = "This item will not work in a Free for All or Tournament game.(Default value is 0)"
      }
      notteam: =
      {
        Txt = "&"
        Hint = "This item will not work in a Teamplay or CTF game.(Default value is 0)"
      }
	light: =
      {
        Txt = "&"
	Hint = "constantLight radius of .md3 model included with entity. Has no effect on the entity's brushes (default 0)."
      }
	color: =
      {
        Txt = "&"
	Hint = "constantLight color of .md3 model included with entity. Has no effect on the entity's brushes (default 1 1 1)."
      }
	notsingle: =
      {
        Txt = "&"
	Hint = "If set to 1, will not spawn in single player (bot play) mode."
      }
	notbot: =
      {
        Txt = "&"
	Hint = "If set to 1, bots will ignore this."
      }
      spawnflags: =
      {
        Txt = "&"
	Typ = "X1"
	Cap = "START_OPEN"
	Hint = "This door will start open."
      }
      spawnflags: =
      {
        Txt = "&"
	Typ = "X4"
	Cap = "CRUSHER"
	Hint = "This will crush the player."
      }
    }
entityDef func_door {
	"editor_color"				"0 .5 .8"
	"editor_mins"				"?"
	"editor_maxs"				"?"
	"editor_mover"				"1"

	"editor_usage"				"Door."
	"editor_bool start_open"		"the door moves to its destination when spawned, and operate in reverse.  It is used to temporarily or permanently close off an area when triggered (not useful for touch or takedamage doors)."

	"editor_bool no_touch"		"the door should not be triggered by the player touching it, only by another trigger. in multiplayer, this door can't be shot to open."
	"editor_bool locked"		"used in conjunction with no_touch,the door must be triggered by a trigger, after which it works normally.  if locked = 1 then the door opens when unlocked, if locked = 2 then the door just becomes unlocked."
	"editor_var buddy"			"will toggle shaderparm 7 of the entity given as a buddy, this allows shaders to be remapped for lock status etc."
	"editor_bool crusher"		"the door does not reverse when blocked."
	"editor_var angle"			"determines the opening direction."
	"editor_var movedir"		"determines the opening direction.  if set, 'angle' determines orientation."
	"editor_var speed"			"movement speed."
	"editor_var time"			"movement time in seconds.  overrides speed.  used for doors that move different distances, but still need to be synced."
	"editor_bool wait"			"wait before returning (-1 = never return)."
	"editor_bool toggle"		"wait at each position until triggered again."
	"editor_var lip"			"lip remaining at end of move."
	"editor_var dmg"			"damage to inflict when blocked."
	"editor_var health"			"if set, the door must be shot open."
	"editor_var triggersize"	"sets the amount the trigger extends from the door."
	"editor_bool gui_noninteractive" "any gui attached will not be interactive"
	"editor_snd snd_locked"		"sound to play if door is locked and player approaches."
	"editor_snd snd_open"		"sound to play when opening."
	"editor_snd snd_close"		"sound to play when closing."
	"editor_snd snd_opened"		"looping sound for it's opened state."
	"editor_var triggerClosed"	"name of entity to trigger when door closes, can be iterated with triggerClosed2, 3 etc."
	"editor_var triggerOpened"	"name of entity to trigger when door opens, can be iterated with triggerOpened2, 3 etc."
	"editor_var triggerBlocked"	"name of entity to trigger when door is blocked, can be iterated with triggerBlocked2, 3 etc."

	"spawnclass"				"idDoor"

	"start_open"				"0"
	"no_touch"					"0"
	"crusher"					"0"
	"angle"						"0"
	"speed"						"100"
	"wait"						"3"
	"lip"						"8"
	"dmg"						"2"
	"health"					"0"
	"triggersize"				"60"
	//"snd_open"					"sound/ed/doors/_door_rust_yellowlight/rust_door_open_test4.wav"
	//"snd_close"					"sound/ed/doors/_door_rust_yellowlight/rust_door_close_test4.wav"
	// More appropriate, less annoying generic door sound
	"snd_close"					"default_door_close"
	"snd_open"					"default_door_open"
	"snd_opened"				""
	"snd_locked"				"default_door_locked"
	"snd_unlocked"				"default_door_unlocked"
}
"""

