# bbox1.py - try to extract bounding boxes from the entity defs

import os, os.path

dirname = "c:\\rowdy\\doom3\\base\\def"

entities = {}
names = os.listdir(dirname)
names.sort()
for name in names:
    if name.endswith(".def"):
        print name
        i = open(os.path.join(dirname, name))
        while 1:
            s = i.readline()
            if s == "":
                break
            s = s.strip()
            if s.startswith("entityDef"):
                s = ' '.join(s.split())
                c = s.split(' ')
                entityName = c[1]
                editorMins = ""
                editorMaxs = ""
            if s.startswith('"editor_mins"'):
                c = s.split('"')
                if c[3] != "?":
                    editorMins = c[3]
                if (editorMins != "") and (editorMaxs != ""):
                    print "    %s %s %s" % (entityName, editorMins, editorMaxs)
            if s.startswith('"editor_maxs"'):
                c = s.split('"')
                if c[3] != "?":
                    editorMaxs = c[3]
                if (editorMins != "") and (editorMaxs != ""):
                    print "    %s %s %s" % (entityName, editorMins, editorMaxs)
                    if entities.has_key(entityName):
                        print "        **** DUPLICATE ENTITY ****"
                        import sys
                        sys.exit
                    entities[entityName] = "%s %s" % (editorMins, editorMaxs)
        i.close()

#print entities

i = open("c:\\eclipse\\workspace_quark\\runtime\\addons\\doom_3\\DataD3.qrk")
o = open("c:\\eclipse\\workspace_quark\\runtime\\addons\\doom_3\\DataD3_bbox.qrk", "w")

foundForms = 0
entitiesDone = []

while 1:
    s = i.readline()
    if s == "":
        break

    # have we found the start of the entity forms yet?
    if s.find("aas48:form") != -1:
        foundForms = 1

    if (foundForms == 1) and (s.find(":form") != -1):
        # see if this is an entity, and whether it appears in the list we gathered earlier
        found = 0
        s1 = s.strip()
        q = s1.find(':')
        s1 = s1[:q]
        #print s1
        if entities.has_key(s1):
            # found it - copy the header from input to output, then write the bbox
            o.write(s)
            o.write(i.readline())
            o.write("      bbox = '%s'\n" % entities[s1])
            entitiesDone.append(s1)
        else:
            # we did not find a bbox for this entity, just write it as is
            o.write(s)
    else:
        # we have found some text before the entity forms, just copy it as is
        o.write(s)

o.close()
i.close()

# now summarise any entities that we found earlier, but which were not found in DataD3.qrk
print
print "entities read but not found in DataD3.qrk:"
for entity in entities.keys():
    if not(entity in entitiesDone):
        print "    %s" % entity

"""
entityDef ammo_bullets_small {
	"editor_color"			".3 .3 1"
	"editor_mins"			"-16 -16 0"
	"editor_maxs"			"16 16 32"
	"editor_rotatable"		"1"

	"editor_usage"			"Small bullets"

	"spawnclass"			"idItem"
	"model"					"models/items/bullet_ammo/bullet_small.lwo"
	"snd_acquire"			"sound/items/clip_pickup_small.wav"
	"size"					"32 32 32"
	"inv_ammo_bullets"		"12"
	"inv_item"				"4"
	"inv_name"				"Bullets"
	"editor_copy100"		"inv_item"
	"snd_respawn"			"sound_item_respawn"

}
"""

